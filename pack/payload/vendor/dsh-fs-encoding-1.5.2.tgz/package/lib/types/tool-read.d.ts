/**
 * The encoding-governed `read` tool.
 *
 * Contract-compatible with the built-in `read` (same `file_path` / `offset` /
 * `limit` arguments, same line-numbered output shape) plus one addition: an
 * `encoding` argument that decodes a file explicitly, mirroring VS Code's
 * "Reopen with Encoding". That argument is what makes a legacy file reachable —
 * without it a GBK file would only ever be a list of candidates.
 *
 * @module dsh-fs-encoding/tool-read
 */
import type { Context } from "@deepseek-ai/cordis";
/**
 * Build the encoding-governed `read` tool.
 *
 * @param ctx - the plugin's host context, which carries `ctx.fs`.
 */
export declare function buildReadTool(ctx: Context): import("@deepseek-ai/dsh-tools").ToolDefinition;
