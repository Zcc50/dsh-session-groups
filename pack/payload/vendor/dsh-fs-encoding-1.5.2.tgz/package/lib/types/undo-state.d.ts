/**
 * The undo history: what one file looked like before its most recent edit.
 *
 * Deliberately a SEPARATE module from `encoding-state`, even though both are
 * per-session maps keyed by a target. The two answer different questions and
 * have different failure modes:
 *
 * - `encoding-state` remembers a few bytes of metadata per file (an encoding
 *   name, a BOM flag). Its bounds are about entry COUNT, because one entry is
 *   cheap.
 * - This module remembers the file's whole PREVIOUS CONTENT. An entry is
 *   therefore as large as the file, and a count bound alone would permit
 *   4096 files x 10 MiB. The bound here is a byte budget, and it is the
 *   load-bearing one.
 *
 * Keeping them apart is also what keeps the encoding memo's guarantees intact.
 * That memo decides how a save encodes; this one only decides what a save can
 * be reverted to. A bug in the undo bookkeeping must not be able to change how
 * a file is written.
 *
 * IN MEMORY ONLY. The plugin promises it writes nothing to disk and pollutes no
 * repository, so an undo point does not survive a DSH restart. That is a real
 * limitation, stated in the README rather than hidden: the tool reports "no undo
 * history" after a restart instead of pretending the edit was never made.
 *
 * @module dsh-fs-encoding/undo-state
 */
import type { FileEncodingState } from "./encoding-state.js";
/** One file's pre-edit state, kept until the next write replaces it. */
export interface UndoRecord {
    /**
     * The file's text before the edit, LF-normalized and BOM-free.
     *
     * Stored in the same normalized form every writer already works in, so
     * restoring it goes back through the ordinary encode path — line endings and
     * BOM come from {@link previousState}, not from this string.
     */
    previousText: string;
    /**
     * The text the edit produced, LF-normalized.
     *
     * This is what makes the undo SAFE rather than merely convenient: before
     * reverting, the tool compares the file's current content against this, and
     * refuses when they differ. Without it, an undo would silently discard any
     * change made after the edit — including another tool's, or the user's own.
     */
    nextText: string;
    /**
     * The version this edit PRODUCED, when the backend reports one.
     *
     * The second half of the staleness check, and the half that catches what the
     * text cannot. {@link nextText} is compared as LF-normalized, BOM-stripped
     * text, so a file whose line endings were converted, whose BOM was added or
     * removed, or whose encoding changed without changing a character compares
     * EQUAL to the record — while being a genuine change by someone else that an
     * undo would silently destroy. The version is the only handle on those.
     *
     * `undefined` when the backend reports no version, in which case the text
     * comparison is the only guard available and is used on its own.
     */
    nextVersion: string | undefined;
    /**
     * The encoding the edit actually wrote, as `writeFile` reported it.
     *
     * Used as the hint for the undo's comparison read, which has to decode the
     * file to compare it against {@link nextText}. Without a hint that read can
     * fail outright: a legacy file whose session encoding record has since been
     * evicted cannot be admitted at all when guessing is off (the default), so the
     * undo would report `E_NOT_TEXT` for a file it is perfectly able to restore —
     * even though this record already knows the encoding.
     *
     * Deliberately NOT {@link previousState}'s encoding, which is the obvious
     * guess and is wrong: with `normalizeToUtf8` the edit MIGRATED the file, so
     * the bytes on disk are UTF-8 while `previousState` says `gbk`. Decoding UTF-8
     * bytes as GBK can still produce acceptable-looking text, which would then
     * fail the text comparison and turn a working undo into a false stale
     * refusal. The post-write encoding is the one that describes what is on disk.
     */
    nextEncoding: string;
    /**
     * How the file was encoded before the edit.
     *
     * Carried in full rather than re-read at undo time for two reasons:
     *
     * 1. **The encoding may have CHANGED.** With `normalizeToUtf8` on, a save
     *    rewrites a legacy file as UTF-8, so the session's record after the edit
     *    describes the bytes the undo is about to replace — not the ones it must
     *    restore. Reverting content without reverting the encoding would leave
     *    the file as UTF-8: half an undo.
     * 2. **The record may be GONE.** `encoding-state` is bounded and evicts, so
     *    reading it at undo time could find nothing and silently fall back to
     *    UTF-8 — which is exactly the silent re-encode this plugin exists to
     *    prevent.
     */
    previousState: FileEncodingState;
    /** Which guard the original write used, so the undo takes the same path. */
    mode: "write" | "edit";
}
/**
 * Record what a file looked like before an edit, replacing any earlier record.
 *
 * One record per file, not a stack: the tool is `undo_last_edit`, so the
 * previous edit is the only one it can reach. A second edit on the same file
 * therefore OVERWRITES the record — undoing twice would need a stack, and the
 * name promises otherwise.
 *
 * The record is skipped entirely when it alone would exceed
 * {@link MAX_UNDO_BYTES}: keeping it would evict every other file's history to
 * hold one file's, and the honest outcome is "this edit cannot be undone"
 * rather than "your other files can no longer be undone".
 *
 * @param sessionKey - the bucket key from `sessionKeyOf`.
 * @param targetKey - the canonical target key.
 * @param record - the pre-edit state.
 */
export declare function recordUndo(sessionKey: string, targetKey: string, record: UndoRecord): void;
/**
 * Read one session's undo record for a file without removing it.
 *
 * @param sessionKey - the bucket key from `sessionKeyOf`.
 * @param targetKey - the canonical target key.
 * @returns the record, or `undefined` when there is nothing to undo.
 */
export declare function getUndo(sessionKey: string, targetKey: string): UndoRecord | undefined;
/**
 * Drop one session's undo record for a file.
 *
 * Called after a successful undo (the history is now spent) and whenever a
 * recorded edit is found to be stale, so a refusal is not repeated forever on a
 * record that can never apply.
 *
 * @param sessionKey - the bucket key from `sessionKeyOf`.
 * @param targetKey - the canonical target key.
 */
export declare function clearUndoFor(sessionKey: string, targetKey: string): void;
/**
 * Release every undo record a session owns.
 *
 * Called when a session ends, mirroring `encoding-state`'s release: without it
 * a long-lived process accumulates one bucket per session that ever ran, each
 * holding whole files.
 *
 * @param sessionId - the session that ended.
 */
export declare function clearSessionUndo(sessionId: string): void;
/** Total undo records across every session. Test seam. */
export declare function undoRecordCount(): number;
/** Total retained content across every session, in UTF-16 units. Test seam. */
export declare function undoByteCount(): number;
/** Drop every session's undo records. Test seam. */
export declare function resetUndoState(): void;
