/**
 * The sandbox fence and the `fs/*` event gate for this plugin's own writers.
 *
 * The plugin publishes bytes itself instead of calling `ctx.fs.writeText`, so
 * it must reproduce what that call would have done on the caller's behalf:
 * resolve the per-call policy, refuse a target outside the writable roots, take
 * the version guard, and record the observation afterwards.
 *
 * Every ingredient here is a PUBLIC seam — `ctx.fs.contains` / `resolve` /
 * `stat`, the `sandboxPolicy` service, `writableRoots`, `approveEscalation`,
 * and the `fs/write-intent` + `fs/edit-intent` + `fs/observed` events. Nothing
 * reaches into a backend's internals, so a backend upgrade cannot silently
 * change what this module means.
 *
 * @module dsh-fs-encoding/sandbox
 */
import type { Context } from "@deepseek-ai/cordis";
import { type FsObservation, type FsTarget, type FsVersion } from "@deepseek-ai/dsh-fs";
import type { SandboxExecutionPolicy, SandboxMode } from "@deepseek-ai/dsh-sandbox";
import type { ToolExecution } from "@deepseek-ai/dsh-tools";
/** The two escalation arguments a mutating tool may carry. */
export interface FsEscalationArgs {
    sandbox_permissions?: string;
    justification?: string;
}
/** The write guard the observation policy answers with. */
export interface WriteIntent {
    kind: string;
    version?: FsVersion;
}
/**
 * Report an observation to the gate, swallowing a listener failure.
 *
 * The one place this plugin emits `fs/observed`. It is exported as a function
 * rather than left as a method because not every emitter has an
 * {@link EncodingSandbox} to hand: `readFile` is called with a bare context, and
 * the read path is the most load-bearing emitter of all.
 *
 * Failures are logged and swallowed. An observation is a RECORD of something
 * that already happened, so a listener that throws cannot change the outcome —
 * failing the call would turn a successful read or write into an error over a
 * bookkeeping step. The cost of a lost record is bounded and known: the policy
 * keeps its previous belief, and the next guarded write either re-reads or
 * refuses, which is the fail-closed direction.
 *
 * @param ctx - the plugin's context, for `emit` and the logger.
 * @param target - the target whose presence or absence was observed.
 * @param observation - present with its version, or confirmed absent.
 * @param exec - the observing execution, which the policy keys its state by.
 */
export declare function emitObservation(ctx: Context, target: FsTarget, observation: FsObservation, exec: ToolExecution | undefined): void;
/**
 * Owns the escalation vocabulary and the per-call fence for this plugin.
 *
 * Mirrors `@deepseek-ai/dsh-tool-fs`'s controller so these tools escalate
 * exactly like the built-ins they shadow: the escalation fields appear in the
 * schema only under a confining backend, a denied operation is retried once at
 * a strictly wider mode through the approval service, and the denial reaches
 * the model as the shared `[sandbox: …]` marker.
 */
export declare class EncodingSandbox {
    private readonly ctx;
    /** Modes this composition advertises; empty when no backend confines. */
    readonly escalationModes: readonly SandboxMode[];
    private readonly policy;
    constructor(ctx: Context);
    /**
     * The escalation fields for a mutating tool's `parameters`.
     *
     * Call only when {@link escalationModes} is non-empty; the enum pins the
     * closed vocabulary, and the strict-wider check happens per call.
     */
    schemaFields(): Record<string, unknown>;
    /**
     * Resolve the policy to stamp onto this mutation: an approved one-shot
     * escalation when the call carries the fields, else the session's standing
     * mode with the calling session's cwd as the workspace root.
     *
     * @param toolName - the mutating tool's name, for the approval audit trail.
     * @param args - the call's escalation arguments.
     * @param exec - the tool execution (agent, callId, signal).
     * @returns the policy to enforce, or `undefined` on an unsandboxed backend.
     */
    resolvePolicy(toolName: string, args: FsEscalationArgs, exec: ToolExecution): Promise<SandboxExecutionPolicy | undefined>;
    /**
     * Enforce the policy against a target and return the exact target the write
     * must use.
     *
     * The containment check re-resolves immediately before returning, so the
     * identity that was checked is the identity that gets written — a symlink
     * swapped between check and write cannot redirect it.
     *
     * @param target - the resolved target about to be written.
     * @param policy - the per-call policy, or `undefined` on an unsandboxed backend.
     * @returns the target to write.
     * @throws {FsError} `FS_SANDBOX_DENIED` when the policy refuses.
     */
    checkedTarget(target: FsTarget, policy: SandboxExecutionPolicy | undefined): Promise<FsTarget>;
    /**
     * Take the write guard for a target.
     *
     * The observation policy answers `createIfAbsent` / `replaceIfVersion` from
     * the version this session last observed; with no policy mounted the bare
     * `undefined` means no guard is taken, exactly as for the built-ins.
     *
     * "No guard" is NOT the same as "no checks", and this method must not be read
     * that way. `writeFile` adds its own refusal — a file that EXISTS while the
     * session holds no encoding record for it is rejected rather than re-encoded as
     * UTF-8 — and that refusal is independent of the policy. So in a composition
     * with no policy mounted, overwriting an existing file still requires reading
     * it first; the plugin will not write a file whose encoding it does not know,
     * because doing so silently replaces every non-ASCII byte of a legacy file.
     * Only a genuinely new file is written unconditionally.
     *
     * @param target - the target about to be written.
     * @param exec - the calling execution, which the policy keys its state by.
     * @returns the guard, or `undefined` when no policy supplies one.
     */
    takeWriteIntent(target: FsTarget, exec: ToolExecution): Promise<WriteIntent | undefined>;
    /**
     * Take the edit guard, which additionally refuses a file never read.
     *
     * @param target - the target about to be edited.
     * @param exec - the calling execution.
     * @returns the version the edit must match, or `undefined` when no policy listens.
     * @throws {FsError} `FS_NOT_OBSERVED` when the file was never read this session.
     */
    takeEditIntent(target: FsTarget, exec: ToolExecution): Promise<{
        version: FsVersion;
    } | undefined>;
    /**
     * Record a successful mutation so the next built-in tool sees the file as
     * observed at the new version.
     *
     * Without this the policy's state stays stale and the very next built-in
     * `write` fails `FS_NOT_OBSERVED` or `FS_STALE_VERSION`.
     *
     * @param target - the target that was written.
     * @param version - the version the write produced, when the backend reports one.
     * @param exec - the calling execution.
     */
    emitObserved(target: FsTarget, version: FsVersion | undefined, exec: ToolExecution): void;
    /**
     * Record that a target is GONE, which is what unlocks the path again.
     *
     * The counterpart to {@link emitObserved}, and the reason it exists: the
     * observation policy keys its guard off the last thing this session knew, so a
     * file that was read and then deleted leaves `present@old-version` behind. The
     * next `fs/write-intent` therefore answers `replaceIfVersion`, and the backend
     * refuses with `FS_STALE_VERSION` ("file no longer exists") — for the rest of
     * the session, because nothing in a write ever clears it. Emitting the absence
     * is what turns that path back into `createIfAbsent`.
     *
     * Called from the write path when the guard expected a file that is not there.
     * That is deliberately the moment AFTER the guard was taken and the refusal is
     * already certain: the record is corrected for the NEXT call, while this one
     * still fails. Emitting before the guard would flip this very call from
     * `replaceIfVersion` to `createIfAbsent` and let it overwrite a file that a
     * concurrent delete-and-rename had momentarily moved aside — the race the
     * guard exists to catch.
     *
     * @param target - the target found to be absent.
     * @param exec - the calling execution.
     */
    emitAbsent(target: FsTarget, exec: ToolExecution): void;
    /**
     * Translate a thrown provider error for the model.
     *
     * A `FS_SANDBOX_DENIED` becomes the shared `[sandbox: …]` denial marker plus
     * the same-turn escalation hint, keeping the structured code. Anything else
     * passes through untouched.
     *
     * @param error - the thrown error.
     * @param policy - the policy the call ran under, for the mode in the marker.
     * @returns the error to rethrow.
     */
    mapError(error: unknown, policy: SandboxExecutionPolicy | undefined): unknown;
}
