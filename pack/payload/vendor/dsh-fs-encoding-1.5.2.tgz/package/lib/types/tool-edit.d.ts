/**
 * The encoding-governed `edit` tool.
 *
 * Contract-compatible with the built-in `edit` (same `file_path` /
 * `old_string` / `new_string` / `replace_all` arguments, same
 * `path`/`before`/`after` result shape and diff card). The difference is
 * entirely in the storage path: the file is decoded under its recorded
 * encoding, matched against LF-normalized text, and re-encoded back into that
 * same encoding, so editing a GBK file leaves it a GBK file.
 *
 * @module dsh-fs-encoding/tool-edit
 */
import type { Context } from "@deepseek-ai/cordis";
import type { EncodingSandbox } from "./sandbox.js";
/**
 * Build the encoding-governed `edit` tool.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 */
export declare function buildEditTool(ctx: Context, sandbox: EncodingSandbox): import("@deepseek-ai/dsh-tools").ToolDefinition;
