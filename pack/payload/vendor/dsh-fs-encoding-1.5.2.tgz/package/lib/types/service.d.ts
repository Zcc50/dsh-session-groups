/**
 * The `ctx.fsEncoding` service: this plugin's decoding rules, exposed to other
 * plugins.
 *
 * The tools this plugin shadows solve encoding for the MODEL. They do nothing
 * for the other half of the harness — a plugin that reads a file to render it
 * for a human (an approval preview, a diff card, a file viewer) goes through
 * `ctx.fs`, whose contract is UTF-8-only by design: it decodes with a strict
 * `TextDecoder`, so a GBK file is simply `FS_NOT_TEXT`. Such a plugin then
 * either shows an error where the file has perfectly readable content, or —
 * worse — reimplements the guess itself, which is how two parts of one
 * deployment end up disagreeing about what a file says.
 *
 * This service is the answer to that: ONE implementation of "what text is in
 * these bytes", owned by the plugin that already owns the question, and
 * callable by anyone.
 *
 * ## What it deliberately does NOT do
 *
 * It does not read files. The caller owns the IO, the sandbox and the path
 * resolution, because those are the caller's context to know — a preview has a
 * session, a cwd and a sandbox fence; this service has none of them. Taking
 * bytes keeps the seam at the narrowest possible point and means a consumer
 * needs no privileges it did not already have.
 *
 * It does not record anything either. A decode here is a QUESTION, not an
 * observation: it must not arm the read-before-write gate, and it must not
 * become the session's recorded encoding, or a preview would silently authorize
 * a later save. Recording stays on the tool path, where the model's read is.
 *
 * READING a record is a different act from MAKING one, and only the second is
 * forbidden here. {@link FsEncodingService.recordedEncoding} reports what a
 * session has already recorded, because a consumer that has to agree with a tool
 * (`edit` takes no `encoding` argument; its encoding is this plugin's own
 * record) cannot recover that answer from the bytes. It derives nothing, writes
 * nothing and gates nothing — see the class doc for the guarantee both halves
 * keep.
 *
 * ## The contract consumers actually need
 *
 * {@link FsEncodingService.decode} answers with the text AND how it was decided
 * ({@link DecodeProvenance}). That distinction is not decoration: a consumer
 * that renders the text has to be able to say "this was guessed" instead of
 * presenting a guess as the file's real encoding. A service that returned only
 * a string would push every consumer into either lying or re-deriving the
 * provenance itself.
 *
 * Refusal is a value, not a throw: {@link FsEncodingService.tryDecode} answers
 * with a discriminated result carrying the refusal and its candidate list.
 * Consumers rendering for a human want to offer those candidates as a chooser,
 * and a thrown `Error` whose message they must parse is a worse seam than a
 * returned one. {@link FsEncodingService.decode} still throws, for a caller that
 * wants the model-facing sentence verbatim.
 *
 * @module dsh-fs-encoding/service
 */
import type { Context } from "@deepseek-ai/cordis";
import type { FsTarget, FsVersion } from "@deepseek-ai/dsh-fs";
import { type DecodeProvenance } from "./encoding-state.js";
import type { CandidatePreview } from "./encoding.js";
declare module "@deepseek-ai/cordis" {
    interface Context {
        /**
         * This plugin's decoding rules, when it is installed.
         *
         * Declared optional on purpose: the plugin is a choice, and a consumer that
         * reads `ctx.fsEncoding` must handle its absence rather than assume it.
         * Reading it through `ctx.get("fsEncoding")` is equivalent and needs no
         * `inject` declaration.
         */
        fsEncoding?: FsEncodingService;
    }
}
/** The service name, as it appears in `ctx.get(name)` and in `inject`. */
export declare const FS_ENCODING_SERVICE = "fsEncoding";
/**
 * What one decode found, in the shape a rendering consumer needs.
 *
 * Deliberately a flat, serializable record rather than the internal admission
 * result: a consumer should not be able to depend on the plugin's internals,
 * and every field here answers a question a preview actually has.
 */
export interface FsDecodeResult {
    /** The decoded text, BOM removed, the file's own line endings intact. */
    text: string;
    /** Canonical encoding identifier that produced {@link text}. */
    encoding: string;
    /**
     * How {@link encoding} was decided.
     *
     * `"guessed"` is the one a consumer must surface: the text is probably right,
     * but it is a probabilistic pick and a human should be told so. The other
     * three are determined, and a consumer may present them as fact.
     */
    decided: DecodeProvenance;
    /** Whether the bytes carried a BOM. */
    hasBOM: boolean;
    /** The dominant line terminator in the decoded text. */
    lineEnding: "\r\n" | "\n" | "\r";
}
/** Why a decode was refused, with everything a consumer needs to explain it. */
export interface FsDecodeRefusal {
    /** A model-facing sentence describing the refusal, ready to display. */
    message: string;
    /**
     * Stable code: `E_NOT_TEXT` for "not decodable text", `E_TOO_LARGE` when the
     * bytes exceed the decode cap, `E_BAD_ENCODING` for a bad argument (an unknown
     * encoding name, or a value of the wrong type). Only `E_NOT_TEXT` carries
     * candidates; the others have nothing to choose between.
     */
    code: string;
    /**
     * The candidate encodings that could decode these bytes, best first.
     *
     * Present on `E_NOT_TEXT`. Empty when nothing decoded cleanly, which normally
     * means binary content — a consumer should say so rather than offer a list.
     */
    candidates: CandidatePreview[];
    /**
     * Whether the candidates are ordered by evidence.
     *
     * `false` means no candidate outranked the others, so the order carries no
     * recommendation and a consumer must not label the head "most likely".
     */
    ranked: boolean;
    /**
     * Whether the head candidate is credible enough to adopt.
     *
     * `false` with `ranked: true` is the dangerous middle case: there IS an order,
     * but the head is a page this plugin has specifically decided is not credible
     * for these bytes. Offering it as a default would reproduce the silent
     * mis-decode the refusal exists to prevent.
     */
    adoptable: boolean;
    /**
     * Whether the effective configuration permits guessing at all.
     *
     * This is what makes the refusal actionable: with guessing off the remedy is
     * to enable it or re-read with an explicit encoding, while with guessing on it
     * is to pick from the candidates. The two are indistinguishable otherwise.
     */
    autoGuessEnabled: boolean;
}
/** Per-call options for {@link FsEncodingService.decode}. */
export interface FsDecodeOptions {
    /**
     * An explicit encoding ("Reopen with Encoding"), which bypasses guessing.
     *
     * This is the same escape hatch the `read` tool offers, so a consumer that
     * shows a candidate list can let a human pick one and pass it straight back.
     */
    encoding?: string | undefined;
    /** Path as the caller knows it, used in refusal messages. */
    displayPath?: string | undefined;
    /**
     * Inclusive byte cap for this decode, defaulting to the plugin's
     * `maxFileBytes`.
     *
     * Exists because this service takes bytes the CALLER read: the tool path gets
     * its cap for free from `fs.readBytes`, while a caller that omitted the cap
     * (the README example did) can hand over an arbitrarily large buffer. The
     * failure path then ranks every allowlisted encoding across the whole buffer,
     * synchronously, which stalls the host event loop for every session — so the
     * bound has to live here too, not only at the read seam.
     */
    maxBytes?: number | undefined;
}
/**
 * What a session has recorded about one file's encoding.
 *
 * The other half of the seam. {@link FsEncodingService.decode} answers "what do
 * these bytes say?", which is enough for a viewer but NOT enough for a consumer
 * that has to agree with a TOOL: `edit`, `insert` and `str_replace_editor` take
 * no `encoding` argument, so their encoding comes from this plugin's own record
 * (`io.ts` reuses it as the hint on every read). A consumer that guessed from
 * the bytes instead can pick a different page and then render a diff against
 * text the tool will never see — measured: a record of `big5` against bytes
 * whose best-scoring candidate is `gbk` decodes to two different documents.
 *
 * Deliberately its own shape rather than the internal `FileEncodingState`:
 *
 * - `decided` and `footer` are optional there because a state may be built by
 *   hand (tests, a caller that only knows the encoding name). That is an
 *   internal construction path, and a consumer should not have to handle a
 *   missing field for a reason that is not about consumers.
 * - `footer` is model-facing prose ("Auto-guessed GBK …"), documented as
 *   "never file content". Putting it in a service contract invites a renderer to
 *   show it as UI text, which is not what it is for.
 * - `version` is internal bookkeeping (an opaque freshness token that
 *   `dsh-fs` says consumers MUST NOT parse). It is deliberately absent: the
 *   staleness QUESTION is answered by the method instead, so a consumer never
 *   reimplements the comparison — see
 *   {@link FsEncodingService.recordedEncoding}.
 */
export interface RecordedEncoding {
    /** Canonical encoding identifier, e.g. `utf8`, `utf8bom`, `gbk`, `utf16le`. */
    encoding: string;
    /**
     * How {@link encoding} was arrived at.
     *
     * Carried because it CANNOT be recovered from the encoding name, and the
     * difference decides how the text may be presented: `hint`/`bom`/`utf8` are
     * determined, `guessed` is a probabilistic pick a human must be told about.
     *
     * A consumer that instead re-decodes with this encoding gets `"hint"` back
     * (the service reports "the CALLER specified this" whenever an explicit
     * encoding is passed), which would present a guess as a determination — the
     * exact failure this plugin exists to prevent.
     */
    decided: DecodeProvenance;
    /** Whether the file carried a byte-order mark when this was recorded. */
    hasBOM: boolean;
    /** The line terminator style a save will restore. */
    lineEnding: "\r\n" | "\n" | "\r";
}
/**
 * The decoding rules of this plugin, as a service.
 *
 * **No method here can change this plugin's state.** `decode` a thousand times
 * is indistinguishable from calling it once, no call writes a record or emits an
 * observation, and nothing here can arm the read-before-write gate.
 *
 * {@link FsEncodingService.recordedEncoding} is the one method that READS
 * session state — it reports what a session has already recorded for a file. It
 * derives nothing and writes nothing; reading a record is not the same act as
 * making one, and only the tool path (where the model's own read is) makes one.
 */
export declare class FsEncodingService {
    #private;
    /**
     * Decode bytes, or refuse with the reason.
     *
     * The non-throwing form, and the one a rendering consumer should use: a
     * refusal is an expected outcome for a binary file or a legacy file with
     * guessing off, not an exception.
     *
     * "Never throws" is a promise about ANY input, not just well-typed input: a
     * consumer is usually another plugin, often plain JavaScript, and it is
     * documented to skip its own `try`. A bad argument is therefore a refusal like
     * any other, never a `TypeError` escaping into the caller. A bad argument is
     * also NOT quietly reinterpreted as "no argument": a mistyped `opts` is
     * refused rather than ignored, so a caller that meant to name an encoding
     * learns that it did not.
     *
     * @param bytes - the file's raw bytes.
     * @param opts - an optional explicit encoding, display path and byte cap.
     *   Omit it for the defaults; passing `null` or a non-object is refused.
     * @returns the decode result, or the refusal.
     */
    tryDecode(bytes: Uint8Array, opts?: FsDecodeOptions | null): Promise<{
        ok: true;
        result: FsDecodeResult;
    } | {
        ok: false;
        refusal: FsDecodeRefusal;
    }>;
    /**
     * Decode bytes, or throw the model-facing refusal.
     *
     * For a caller that wants the plugin's own wording — the same sentence the
     * `read` tool would produce, candidate list and suggested re-read included.
     *
     * @param bytes - the file's raw bytes.
     * @param opts - an optional explicit encoding and display path. Omit it for
     *   the defaults; passing `null` or a non-object is refused.
     * @returns the decode result.
     * @throws {DecodeError} when the bytes cannot be admitted.
     */
    decode(bytes: Uint8Array, opts?: FsDecodeOptions | null): Promise<FsDecodeResult>;
    /**
     * Whether these bytes are valid UTF-8 — NOT whether `ctx.fs.readText` will
     * accept them.
     *
     * The two questions differ, and the difference is reachable: `readText`
     * rejects a NUL byte in the leading sample as binary, while a NUL byte is
     * perfectly valid UTF-8 (it is the ASCII NUL). Measured: UTF-16LE bytes
     * without a BOM (`61 00 62 00`) are valid UTF-8 and are refused by `readText`
     * with `FS_NOT_TEXT`. A caller that uses this as a "will readText work" probe
     * must therefore still handle that refusal.
     *
     * Exposed because the common case deserves to stay cheap: a consumer that
     * only needs to know whether the bytes are UTF-8 should not have to run
     * admission (and a possible chardet pass) to find out.
     *
     * @param bytes - the bytes to test.
     * @returns whether a strict UTF-8 decode succeeds.
     */
    isUtf8(bytes: Uint8Array): boolean;
    /**
     * The encodings this deployment will consider when guessing.
     *
     * The EFFECTIVE set: the shipped default, minus the config's exclusions, or
     * the explicit list the operator wrote. A consumer that wants to offer a
     * chooser should use this rather than its own list, or it will offer pages
     * this deployment has deliberately excluded.
     *
     * @returns canonical encoding names.
     */
    supportedEncodings(): string[];
    /**
     * Every encoding name this plugin can decode, regardless of configuration.
     *
     * Distinct from {@link supportedEncodings}: this is the vocabulary (what a
     * name may be), that is the policy (what this deployment will try). An
     * explicit `encoding` may name anything in here.
     *
     * @returns canonical encoding names.
     */
    knownEncodings(): string[];
    /**
     * Whether this deployment decodes a non-UTF-8 file by guessing.
     *
     * Exposed so a consumer can explain a refusal correctly without parsing the
     * message: `false` means "no attempt was made", not "the attempt failed".
     *
     * @returns the effective `autoGuessEncoding`.
     */
    autoGuessEnabled(): boolean;
    /**
     * What one session has recorded for one file, or `undefined` when there is no
     * usable record.
     *
     * The method a consumer needs when it must agree with a TOOL rather than
     * merely display bytes. `edit`, `insert` and `str_replace_editor` take no
     * `encoding` argument; their encoding is whatever this plugin recorded when
     * the file was read in that session, reused as the hint on every later read.
     * Decoding the same bytes by guessing can land on a different page, and the
     * resulting diff would then describe text the tool never touches.
     *
     * **This is a question, not an observation.** It writes no record, emits no
     * event, arms no gate, and cannot make a write possible that was not possible
     * before — the guarantee {@link FsEncodingService} states for every method it
     * offers. A consumer that renders a preview can call it freely.
     *
     * **Staleness is answered here, not left to the caller.** Pass the version
     * just observed from `ctx.fs.stat` and a record taken at a different version
     * is reported as `undefined`, using the same comparison the write path uses to
     * discard one.
     *
     * Omitting the argument is NOT "skip the check": it is read exactly as the
     * write path reads an absent version (`invalidateIfStale(sessionKey, key,
     * version)`), so a record that carries a version but is asked about without
     * one is reported as `undefined`. That is the fail-closed direction, and it is
     * deliberate — `undefined` is what a caller gets when it could not observe the
     * file (a `stat` that returned nothing), and answering "here is the record"
     * there is how a consumer ends up describing a file the tool will refuse to
     * write. A caller that genuinely wants the record as it stands, fresh or not
     * (to show history, say), says so explicitly with `null`.
     *
     * `undefined` therefore means "no usable record" and collapses two causes: the
     * session never recorded this file, or the record no longer matches the file.
     * They are reported alike because the ACTION is the same — fall back to
     * decoding the bytes and presenting the result as a guess — and telling them
     * apart would require exposing the version token, which is exactly the
     * internal detail this method exists to keep out of the contract.
     *
     * Cross-session reads are allowed, and safe: this reports what a session
     * recorded, while the encoding a WRITE uses is derived from the calling
     * session alone (`sessionKeyFor(exec)`). Reading another session's record can
     * therefore inform a display, but never change what gets written. Pass
     * `undefined` for an agentless caller; it reads the anonymous bucket, which is
     * distinct from every real session's.
     *
     * Never throws: an unusable `target` or `sessionId` answers `undefined`, the
     * same promise {@link FsEncodingService.tryDecode} makes for its arguments.
     *
     * @param sessionId - the session whose record is wanted, or `undefined` for
     *   the agentless bucket.
     * @param target - the resolved target; a target, not a path, because resolving
     *   a path may perform I/O and this service does none.
     * @param currentVersion - the version just observed for the file; omit it when
     *   you could not observe one (fail-closed, as the write path reads it), or
     *   pass `null` to skip the staleness check deliberately.
     * @returns the record, or `undefined` when there is none to trust.
     */
    recordedEncoding(sessionId: string | undefined, target: FsTarget, currentVersion?: FsVersion | null): RecordedEncoding | undefined;
}
/**
 * Whether a value can be used as this plugin's decoding service.
 *
 * A consumer should use this rather than `=== undefined`. When another plugin has
 * already registered the name `fsEncoding`, cordis keeps the FIRST provider's
 * object in its store and the later `provide` throws — so `ctx.get` answers with
 * a foreign object, not `undefined`, and calling `tryDecode` on it throws
 * `TypeError` inside the consumer. Checking the capability is what makes the
 * lookup safe in that deployment.
 *
 * The predicate is deliberately typed as the methods it actually verifies, NOT
 * as the whole class. Claiming the full type would let a consumer call
 * `supportedEncodings()` (or any other member) with no compile error and fail at
 * runtime — the type must not promise more than the check proves.
 *
 * Name the methods you need to ask the precise question:
 *
 * ```js
 * isFsEncodingService(svc)                        // tryDecode + decode
 * isFsEncodingService(svc, "recordedEncoding")    // just that one
 * ```
 *
 * The names matter because a service instance may be OLDER than the consumer's
 * idea of it: the first registration of the name wins, so a mount can be handed
 * an earlier build of this plugin, and a method added since then is simply
 * absent. Checking a fixed list cannot express that — verifying less than the
 * consumer calls lets the call throw, and verifying more rejects an instance
 * whose decode entry points work perfectly. Asking for exactly what will be
 * called is the only form that is right in both directions, and it is why
 * {@link FsEncodingService.recordedEncoding} is NOT in the default set: a build
 * that predates it still answers the decode question correctly.
 *
 * Omitting the names keeps the historical answer (`tryDecode` + `decode`), which
 * is what `index.ts` grades its duplicate-provider diagnosis on: widening the
 * default would make it report a service that HAS the decode entry points as one
 * that does not.
 *
 * The no-names form is also a PLAIN one-argument predicate, and that is
 * load-bearing rather than incidental: the historical signature was unary, so
 * consumers pass this function itself as a callback —
 * `candidates.filter(isFsEncodingService)`. A variadic signature breaks every
 * one of those, because `filter` passes the ELEMENT INDEX as the second
 * argument: `required` becomes `[0]`, the predicate then asks whether the object
 * has a method named `"0"`, and a perfectly good service answers `false`.
 * Measured: `filter` drops 2 matches to 0 and `every` flips from `true` to
 * `false`, with no error anywhere — the callback position turns a variadic
 * signature into a silently wrong answer rather than a compile failure. Both
 * halves below exist for that reason: the unary overload keeps the usage typed,
 * and the runtime drops non-string names so the plain-JavaScript callback (which
 * no overload can reach) still answers correctly.
 *
 * @param value - whatever `ctx.get("fsEncoding")` returned.
 * @param required - the members the caller is about to use; omit for the decode
 *   entry points (`tryDecode`, `decode`).
 * @returns whether the value offers every named member.
 */
export declare function isFsEncodingService(value: unknown): value is Pick<FsEncodingService, "tryDecode" | "decode">;
export declare function isFsEncodingService<K extends keyof FsEncodingService>(value: unknown, ...required: readonly [K, ...K[]]): value is Pick<FsEncodingService, K>;
/**
 * Register the service on the plugin's own context.
 *
 * Host-plane, like `ctx.fs` itself: the decoding RULES do not vary per agent or
 * per session, so one registration at load time is the whole install. The
 * per-session half — the recorded encodings — is reached through
 * {@link FsEncodingService.recordedEncoding}, which takes the session as an
 * argument rather than requiring one registration per session: the records are
 * keyed by session inside this plugin, so a single host-plane instance can
 * answer for any of them, and a consumer that has no agent in hand (a preview
 * rendering before a session exists) is served by the same object. Cordis
 * removes it when the plugin's fiber unloads.
 *
 * @param rootCtx - the host-plane plugin context.
 * @returns the service instance, for diagnostics and tests.
 * @throws when the name is already provided on this scope; the caller decides
 *   whether that is fatal. It is NOT swallowed here, because a silent failure
 *   would leave consumers reading a foreign object while the operator believes
 *   the service was published.
 */
export declare function provideFsEncoding(rootCtx: Context): FsEncodingService;
