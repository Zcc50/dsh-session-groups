/**
 * The file-encoding state round-trip: decode-at-open, invert-at-save.
 *
 * One module owns the whole invariant. A file's encoding is decided exactly
 * once, when it is first read in a session, and recorded against the target's
 * canonical key together with the version it was read at. Every later save
 * inverts that record instead of re-deriving it, so a file cannot drift to a
 * different encoding just because a heuristic scored differently on the edited
 * content.
 *
 * The record is invalidated by version: if the file changed on disk since it
 * was read, the memo is dropped and the next read re-runs deterministic
 * admission. A stale record can therefore never authorize a write.
 *
 * @module dsh-fs-encoding/encoding-state
 */
import { type CandidatePreview } from "./encoding.js";
import { type LineEnding } from "./line-endings.js";
/** What was learned about one file the first time it was read this session. */
export interface FileEncodingState {
    /** Canonical encoding identifier, e.g. `utf8`, `utf8bom`, `gbk`, `utf16le`. */
    encoding: string;
    /** Whether the file carried a byte-order mark. */
    hasBOM: boolean;
    /** The line terminator style to restore on save. */
    lineEnding: LineEnding;
    /**
     * The `ctx.fs` version observed when this state was recorded, or `undefined`
     * when the backend reports none. A mismatch invalidates the entry.
     */
    version: string | undefined;
    /**
     * How this encoding was arrived at, carried forward from the read that
     * established it.
     *
     * A save does not re-derive the encoding — it inverts this record — so the
     * provenance must survive the write, or the second read of a guessed file
     * would report the guess as a decision. Optional because a state may be built
     * by hand (tests, and a caller that only knows the encoding name).
     */
    decided?: DecodeProvenance | undefined;
    /**
     * The provenance note shown with this file's reads ("auto-guessed GBK …"),
     * carried so a later read in the same session can repeat it. A guess must
     * stay visible on every read, not only the one that made it.
     */
    footer?: string | undefined;
}
/**
 * Session key used for a caller with no session (tests, previews).
 *
 * A distinct bucket rather than a shared "global" one: an agentless read must
 * not be able to satisfy a real session's read-before-write gate, nor inherit
 * an encoding another caller chose.
 */
export declare const ANONYMOUS_SESSION = "\0anonymous";
/**
 * Resolve the bucket for a session id.
 *
 * @param sessionId - the calling session's id, or `undefined` for an agentless caller.
 * @returns the bucket key.
 */
export declare function sessionKeyOf(sessionId: string | undefined): string;
/**
 * Read the state one session recorded for a file.
 *
 * @param sessionKey - the bucket key from {@link sessionKeyOf}.
 * @param targetKey - the canonical target key.
 * @returns the recorded state, or `undefined`.
 */
export declare function getEncodingState(sessionKey: string, targetKey: string): FileEncodingState | undefined;
/** Record a state for one session and file. */
export declare function setEncodingState(sessionKey: string, targetKey: string, state: FileEncodingState): void;
/**
 * Drop one session's record for a file, all of one session's records, or
 * everything.
 *
 * @param sessionKey - the session to clear; omit to clear every session.
 * @param targetKey - the file to clear; omit to clear the whole session.
 */
export declare function clearEncodingState(sessionKey?: string, targetKey?: string): void;
/**
 * Release every record a session owns.
 *
 * Called when a session ends. Without it a long-lived process accumulates one
 * bucket per session that ever ran.
 *
 * @param sessionId - the session that ended.
 */
export declare function clearSession(sessionId: string): void;
/**
 * Whether a record was taken at a different version than the one just observed.
 *
 * The single definition of "this record no longer describes the file", shared by
 * the write path (which DELETES on a mismatch) and the service (which REPORTS
 * one, because a query must not change state). Two copies of this comparison
 * would eventually disagree, and the disagreement would be visible: a preview
 * and the tool that follows it would answer "is this record still good?"
 * differently, which is the class of inconsistency the service exists to end.
 *
 * A plain `!==`, deliberately: `undefined` on either side means "no version was
 * reported" and compares unequal to a real one. That is the fail-closed reading
 * — an unversioned record cannot be confirmed fresh — and it is why a caller
 * that CAN pass the current version should.
 *
 * @param state - the recorded state.
 * @param currentVersion - the version just observed, or `undefined` when absent.
 * @returns whether the record must not be trusted.
 */
export declare function isStale(state: FileEncodingState, currentVersion: string | undefined): boolean;
/**
 * Drop a recorded state when the file's version no longer matches.
 *
 * This is the guard that keeps a stale encoding from authorizing a write: the
 * caller stats the file, passes the current version, and any record taken at a
 * different version is discarded before it can be inverted.
 *
 * @param sessionKey - the bucket key from {@link sessionKeyOf}.
 * @param targetKey - canonical target key.
 * @param currentVersion - the version just observed, or `undefined` when absent.
 */
export declare function invalidateIfStale(sessionKey: string, targetKey: string, currentVersion: string | undefined): void;
/** Number of sessions currently tracked. Test seam. */
export declare function sessionCount(): number;
/** Total number of recorded file states across every session. Test seam. */
export declare function encodingStateCount(): number;
/**
 * How an encoding was arrived at, for callers that must not present a guess as
 * a fact.
 *
 * The distinction is the whole point of this field: `hint`, `bom` and `utf8`
 * are DETERMINED — the caller said so, the bytes said so, or the bytes are
 * valid UTF-8 — while `guessed` is a probabilistic pick that a later reader may
 * disagree with. A consumer that renders text for a human (an approval preview,
 * a diff card) has to say which one it got, because silently presenting a guess
 * as the file's real encoding is the failure this plugin exists to prevent.
 */
export type DecodeProvenance = "hint" | "bom" | "utf8" | "guessed";
/**
 * The provenance a recorded state carries, including the legacy footer rule.
 *
 * The single definition of "what did this record say about how its encoding was
 * decided", shared by the read path (which feeds it to `openStateFor` so a
 * memo-reusing read does not relabel a guess as a determination) and the service
 * (which reports it to a consumer that must agree with a tool). Two copies would
 * eventually disagree, and the disagreement would be visible in exactly the way
 * this field exists to prevent: one side presenting a guess as a determination.
 *
 * A record that predates `decided` is read from its `footer`, which is written
 * ONLY by the guess path — so its presence proves the encoding was guessed. A
 * record with NEITHER field can only come from a caller that knew the encoding
 * name, which is what `"hint"` means; that reading is left to the caller rather
 * than answered here, because the read path already has a `"hint"` from
 * admission to fall back on while the service has to supply its own.
 *
 * @param state - the recorded state, or `undefined` when there is none.
 * @returns the provenance, or `undefined` when the record does not say.
 */
export declare function provenanceOf(state: FileEncodingState | undefined): DecodeProvenance | undefined;
/** The outcome of admitting a byte buffer for reading. */
export interface DecodeForOpenResult {
    /** The decoded text, with any BOM already removed. */
    text: string;
    /** Canonical encoding identifier that produced {@link text}. */
    encoding: string;
    /** How {@link encoding} was decided. */
    decided: DecodeProvenance;
    /** Whether the bytes carried a BOM. */
    hasBOM: boolean;
    /** Line terminator style detected in the decoded text. */
    lineEnding: LineEnding;
    /** An out-of-band note for the model (auto-guess provenance), never file content. */
    footer?: string;
    /** Scored candidates, populated on the guessing paths. */
    candidates: CandidatePreview[];
}
/** Inputs that decide how permissive admission may be. */
export interface DecodeAdmissionConfig {
    /** Whether a non-UTF-8 file may be decoded by guessing. */
    autoGuessEncoding: boolean;
    /** Encodings considered when guessing. */
    supportedEncodings: readonly string[];
}
/** Per-call admission options. */
export interface DecodeForOpenOptions {
    /** An explicit encoding ("Reopen with Encoding"); bypasses guessing entirely. */
    encodingHint?: string;
    /** Path as the model wrote it, used in error messages. */
    displayPath?: string;
}
/**
 * The machine-readable half of a refusal, for callers that are not the model.
 *
 * The message is written for the model to act on; this is what a programmatic
 * consumer needs so it does not have to parse that prose. An approval preview,
 * for instance, wants to offer the candidate list as a chooser — and it cannot
 * recover the list from a sentence.
 */
export interface DecodeErrorDetail {
    /** Scored candidates, in the order the message lists them. Empty for binary input. */
    candidates: readonly CandidatePreview[];
    /** Whether one candidate outranked the others, so the order is meaningful. */
    ranked: boolean;
    /**
     * Whether the head candidate was credible enough to adopt. `false` with
     * `ranked: true` means the list is offered as candidates rather than as a
     * decision — the head is present but should not be recommended.
     */
    adoptable: boolean;
    /**
     * Whether the effective configuration permits guessing at all.
     *
     * A consumer that wants to explain the refusal needs this: with guessing off
     * the remedy is "turn on autoGuessEncoding or re-read with an explicit
     * encoding", while with guessing on it is "pick from the candidates". The two
     * are indistinguishable from the message alone.
     */
    autoGuessEnabled: boolean;
}
/** A decode failure the caller must surface verbatim. */
export declare class DecodeError extends Error {
    readonly code: string;
    /**
     * Structured detail, present on the admission refusals that have candidates
     * to offer. Absent on the argument-level failures (unknown encoding name,
     * a wrong explicit encoding), which have nothing to choose between.
     */
    readonly detail?: DecodeErrorDetail | undefined;
    constructor(message: string, code: string, 
    /**
     * Structured detail, present on the admission refusals that have candidates
     * to offer. Absent on the argument-level failures (unknown encoding name,
     * a wrong explicit encoding), which have nothing to choose between.
     */
    detail?: DecodeErrorDetail | undefined);
}
/**
 * Admit a raw byte buffer and decide how to decode it.
 *
 * The order is fixed and must not be reordered: an explicit hint always wins
 * (the caller has already chosen), then a BOM is authoritative, then strict
 * UTF-8, and only then — gated by config — probabilistic guessing.
 *
 * Pure: no IO and no memo writes. The caller records the result via
 * {@link recordOpenState} once it knows the target key and version.
 *
 * @param bytes - the whole file's bytes.
 * @param config - how permissive admission may be.
 * @param opts - per-call options (explicit hint, display path).
 * @returns the decoded text and the state to remember.
 * @throws {DecodeError} when nothing decodes the bytes.
 */
export declare function decodeForOpen(bytes: Uint8Array, config: DecodeAdmissionConfig, opts?: DecodeForOpenOptions): Promise<DecodeForOpenResult>;
/**
 * Build the state a read established, WITHOUT recording it.
 *
 * Split out from {@link recordOpenState} because the two must be separable: a
 * read whose only purpose is to render a diff learns an encoding but must not
 * make it the session's answer. Recording a guess from a presentation-only read
 * would let that guess authorize a later save, which is exactly the silent
 * re-encode the write guard exists to refuse.
 *
 * @param decoded - the admission result.
 * @param version - the version observed at read time, used for later invalidation.
 * @param provenance - the real provenance when the decode did not establish it.
 *   A read that reused the session's own memo passes the recorded value here:
 *   the hint path reports `"hint"` because a hint is what it was given, but a
 *   hint this plugin supplied from its own memo is not a caller's decision, and
 *   re-labelling it would present a guess as a determination.
 * @returns the state, unrecorded.
 */
export declare function openStateFor(decoded: DecodeForOpenResult, version: string | undefined, provenance?: DecodeProvenance | undefined): FileEncodingState;
/**
 * Record what a read learned about a file, for one session.
 *
 * @param sessionKey - the bucket key from {@link sessionKeyOf}.
 * @param targetKey - the resolved target's canonical key.
 * @param decoded - the admission result.
 * @param version - the version observed at read time, used for later invalidation.
 * @param provenance - see {@link openStateFor}; carried so a memo-reusing read
 *   does not overwrite the recorded provenance with the `"hint"` it was handed.
 * @returns the recorded state.
 */
export declare function recordOpenState(sessionKey: string, targetKey: string, decoded: DecodeForOpenResult, version: string | undefined, provenance?: DecodeProvenance | undefined): FileEncodingState;
/** A character that the target encoding cannot represent. */
export interface UnmappableChar {
    /** The offending character. */
    char: string;
    /** Its Unicode code point. */
    codePoint: number;
    /** Character offset in the text being saved. */
    index: number;
}
/** A save that cannot proceed without corrupting content. */
export declare class UnmappableError extends Error {
    readonly detail: UnmappableChar;
    readonly encoding: string;
    constructor(message: string, detail: UnmappableChar, encoding: string);
}
/** How a save should treat the recorded encoding. */
export interface EncodeForSaveOptions {
    /** Rewrite a legacy file as UTF-8 instead of preserving its encoding. */
    normalizeToUtf8?: boolean;
    /**
     * The encoding to create a file in that has no recorded state, when the caller
     * named one explicitly. Ignored whenever `state` is present: an existing file's
     * own encoding always wins, which is this plugin's core contract.
     */
    newFileEncoding?: string | undefined;
}
/**
 * Turn edited text back into the bytes that should be written.
 *
 * This is the inverse of {@link decodeForOpen} and the one place where an
 * encoding round-trip can silently corrupt a file. Three rules keep it honest:
 *
 * - **Preserve by default.** With a recorded legacy encoding and
 *   `normalizeToUtf8: false`, the text is re-encoded in that encoding, so an
 *   edit changes only the edited characters.
 * - **Verify the round-trip.** `iconv-lite` substitutes `?` for characters the
 *   target encoding cannot represent. That substitution is detected by decoding
 *   the result and comparing, and it fails the save rather than writing a file
 *   whose content no longer matches what the model asked for.
 * - **Only add a BOM, never invent one.** A BOM is restored exactly when the
 *   file had one; a new file never gains one.
 *
 * @param content - the edited text, as returned by the tools (BOM-free).
 * @param state - the recorded state, or `undefined` for a file never read.
 * @param opts - save policy (migration toggle).
 * @returns the bytes to publish, plus the encoding they were actually written
 *   in — which differs from the recorded one when migration converted a legacy
 *   file to UTF-8. The caller must record THIS encoding, or the session's next
 *   read would decode the migrated bytes under the old one.
 * @throws {UnmappableError} when the target encoding cannot represent the content.
 */
export declare function encodeForSave(content: string, state: FileEncodingState | undefined, opts?: EncodeForSaveOptions): {
    bytes: Uint8Array;
    encoding: string;
    hasBOM: boolean;
};
/** Test seam: drop every session's recorded state. */
export declare function resetEncodingState(): void;
