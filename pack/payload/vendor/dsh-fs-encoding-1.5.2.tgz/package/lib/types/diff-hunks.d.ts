/**
 * Minimal line diff for the tool result cards.
 *
 * The UI counts changed lines from the hunks a tool reports: every line of a
 * hunk's `oldText` counts as removed and every line of its `newText` as added.
 * Reporting the whole file — which is what passing `before`/`after` straight
 * through does — makes a one-line edit read as "changed 2,400 lines", and the
 * user reasonably concludes the plugin rewrote their file. It did not; only the
 * card was wrong. This module produces one hunk per changed region, so the count
 * matches what actually changed.
 *
 * The harness uses the `diff` package's `structuredPatch`. This is a
 * self-contained equivalent for the one thing the cards need. Deliberately not
 * that dependency: it is ~600 kB unpacked across 136 files, larger than this
 * plugin's two runtime dependencies combined, and it is not importable from here
 * anyway — it is an internal dependency of `@deepseek-ai/dsh-tool-fs`, not a
 * declared peer, so a plugin that wants it must ship its own copy.
 *
 * ## Why a real diff and not a prefix/suffix trim
 *
 * Trimming the common prefix and suffix is enough for a SINGLE changed region,
 * and that is what an earlier revision of this module did. It is not enough for
 * the common case of two changes far apart: the whole span between them counts
 * as changed. Measured on a 100-line file with three scattered edits, the trim
 * reported +97/-97 where the harness reports +21/-21 — the original complaint,
 * unfixed. Separating changes requires the actual LCS, so this computes one with
 * the Myers algorithm over lines.
 *
 * ## No context lines, unlike the harness — see {@link DIFF_CONTEXT}
 *
 * The harness emits 3 context lines per hunk. Copying that made every unchanged
 * line render as BOTH a deletion and an addition, because `FileDiff` cannot mark
 * a line as context. This module emits the changed lines only.
 *
 * ## The trailing newline belongs to the last line
 *
 * A save that only adds or removes a file's final newline changes its bytes, so it
 * has to produce a hunk. Comparing line ARRAYS cannot see that — `"a\nb"` and
 * `"a\nb\n"` split into the same two lines — which reported such a save as "nothing
 * changed" and, on `write`, made the UI fall back to the whole-file diff this
 * module exists to remove. The final line is therefore compared together with its
 * newline, the same fact `structuredPatch` encodes with its
 * `\ No newline at end of file` marker. When both sides end the same way — every
 * file that ends with a newline, which is nearly all of them — this reduces to
 * plain line equality.
 *
 * ## Bounded work
 *
 * The trace is one diagonal window per round and the search stops at
 * {@link MAX_EDIT_DISTANCE}, so a call cannot allocate without limit; see that
 * constant for what the bound costs and why it is the safe answer.
 *
 * @module dsh-fs-encoding/diff-hunks
 */
/**
 * Context lines kept on each side of a change. Deliberately ZERO.
 *
 * The harness's own `DIFF_CONTEXT` is 3, and copying that number is what this
 * module did first. It is wrong HERE, because the harness's context lines are
 * never rendered as context: `FileDiff` carries only `oldText` and `newText`, and
 * the UI's `diffRows` pushes every line of `oldText` as a `del` row and every
 * line of `newText` as an `add` row, with no per-line alignment and no notion of
 * an unchanged line. So each context line is shown TWICE — once as removed, once
 * as added — and a one-line edit renders as "deleted 7, added 7".
 *
 * Measured on the real card: editing one line of a 9,441-line file with
 * `DIFF_CONTEXT = 3` displayed six unchanged lines under `-` and the same six
 * again under `+`, with the card totalling `+7 -7` while the message said
 * `Added 1 line(s), removed 1 line(s)`.
 *
 * Zero is also what the harness's own CALL-time presenter does: `presentCall`
 * puts `old_string`/`new_string` straight into `oldText`/`newText` — pure changed
 * lines, no context — which is the semantics this structure actually has. The
 * harness's `computeHunkDiffs` added context for the result card without the UI
 * ever learning to render it, so the two disagree; this module follows the
 * structure rather than the mismatch.
 *
 * The cost is real and accepted: the card no longer shows the neighbourhood of a
 * change. The counts are now honest and match the message, which is what a reader
 * checks first, and the surrounding lines are one `read` away.
 */
export declare const DIFF_CONTEXT = 0;
/**
 * Largest edit distance this module will search for.
 *
 * The trace keeps one packed diagonal window per round, so an unbounded search
 * costs `O(D²)` memory and `O(D²)` time. The bound is what keeps a whole-file
 * rewrite of a large file — the case where `D` approaches `n + m` — from
 * allocating gigabytes inside a tool result renderer: measured on the unbounded
 * version, 30,000 lines rewritten as one line reached 3.8 GB and 8,000 lines of
 * entirely different text reached 1.5 GB, and `Int32Array` storage is off-heap,
 * so it is not stopped by `--max-old-space-size` and instead consumes physical
 * memory until the process dies. The plugin's own read cap (`maxFileBytes`,
 * 10 MiB by default) is far above what this algorithm can survive, so the cap
 * cannot stand in for a bound here.
 *
 * The value is a deliberate compromise, because reaching the bound is not free:
 * past it the card collapses to a single whole-file region and the reported
 * counts become the two file sizes rather than the real edit, so a file with
 * 1,001 changed lines would be described as if all 3,000 had changed. The bound
 * therefore has to sit above any edit a real tool call produces, and it does:
 * the counts only stop being exact past `MAX_EDIT_DISTANCE / 2` changed lines,
 * which is 3,000 lines here.
 *
 * A fixed bound rather than one scaled to the input, because the memory has to
 * stay predictable: the packed trace is `2 × (D+1) × (D+2)` bytes, ~69 MB at the
 * bound, whatever the file size. Scaling it would let a 200,000-line file raise
 * the ceiling to hundreds of MB per call, which is the failure this constant
 * exists to prevent.
 *
 * The bound also caps TIME, not just memory, and that is not a side effect worth
 * losing: the harness's own unbounded `structuredPatch` needs 37 seconds to
 * produce the single whole-file hunk that this returns in 0.24 seconds for the
 * same 20,000-line rewrite, because its cost is `O((n+m)·D)` with `D` at its
 * worst. Past the bound this module stops searching and reports the answer it
 * already knows.
 */
export declare const MAX_EDIT_DISTANCE = 6000;
/**
 * One changed region, in the shape the UI's diff card expects.
 *
 * The index signature is what lets these objects travel through the tool result
 * metadata, which is typed as `JsonValue` — a plain interface is not assignable
 * to that without one.
 */
export interface FileDiff {
    [key: string]: string | null;
    /** The model-facing path, stamped on the diff. */
    path: string;
    /** Lines before the change, or `null` for a pure insertion. */
    oldText: string | null;
    /** Lines after the change. */
    newText: string;
}
/**
 * Compute one {@link FileDiff} per changed region between `before` and `after`.
 *
 * With {@link DIFF_CONTEXT} at 0 that is one region per run of changed lines —
 * deliberately NOT the built-ins' shape, which keeps 3 context lines per hunk and
 * which the card cannot render as context (see the constant). Regions carry the
 * changed lines only, so the card counts exactly the lines the message reports.
 *
 * A change whose edit distance exceeds {@link MAX_EDIT_DISTANCE} is reported as a
 * single whole-file diff. That is the honest answer — the file really was
 * rewritten — and it is the bounded one: computing the fine-grained regions would
 * require the trace this module refuses to grow without limit.
 *
 * @param path - the path stamped on every produced diff.
 * @param before - the file text before the change.
 * @param after - the file text after the change.
 * @returns one diff per changed region, in file order; empty when identical.
 */
export declare function computeHunkDiffs(path: string, before: string, after: string): FileDiff[];
/** How many lines a change added and removed, context excluded. */
export interface LineChangeCount {
    /** Lines present after the change that were not there before. */
    added: number;
    /** Lines present before the change that are gone. */
    removed: number;
}
/**
 * Count the lines a change actually added and removed.
 *
 * Kept separate from {@link computeHunkDiffs} because the two answer different
 * questions — this one counts the edit script's inserts and removes, that one
 * returns the regions to render — and not because the numbers differ: with
 * {@link DIFF_CONTEXT} at 0 a region holds exactly the changed lines, so both
 * surfaces report the same totals. Counting the regions would have inflated a
 * one-line edit to "added 7, removed 7" back when they carried context lines, the
 * same class of inflation as the whole-file diff bug, just smaller.
 *
 * A line that changed in place counts once on each side, which is what a reader
 * expects from "added 1, removed 1" for a one-line edit.
 *
 * Over {@link MAX_EDIT_DISTANCE} the whole of both sides is reported as changed,
 * matching the single whole-file diff {@link computeHunkDiffs} produces for the
 * same input — the two must agree, or the card and the message would describe
 * different changes.
 *
 * @param before - the file text before the change.
 * @param after - the file text after the change.
 * @returns the added and removed line counts.
 */
export declare function countLineChanges(before: string, after: string): LineChangeCount;
/**
 * The summary appended to a tool's message so the model can see the size of what
 * it just did.
 *
 * Phrased as a plain sentence appended to the built-in's own wording, so a tool
 * that already reports "the file was updated" gains the counts without the two
 * readings as separate statements.
 *
 * @param count - the added/removed counts.
 * @returns the sentence fragment, or `""` when nothing changed.
 */
export declare function formatLineChangeSummary(count: LineChangeCount): string;
/**
 * The same counts as a parenthetical, for the `write` result block.
 *
 * `write` answers in an XML-shaped block whose `<content>` element already ends
 * with a verb phrase ("Created file"), so a second sentence there would read as
 * two statements. A parenthetical attaches to the phrase instead.
 *
 * @param count - the added/removed counts.
 * @returns the parenthetical, or `""` when nothing changed.
 */
export declare function formatChangeParenthetical(count: LineChangeCount): string;
/**
 * How many lines a text has, counted the way the tools report it.
 *
 * A trailing newline does not open a new line, so a file whose content ends with
 * one is not reported as one line longer than it looks. Text that is nothing but
 * newlines counts as zero lines, matching `read`'s `totalLines` (see
 * `line-endings.splitLines` and `tool-read`): the two are the same model-facing
 * vocabulary, and a model that creates a file reported as "1 line" must not then
 * read it back as "0 lines".
 *
 * @param text - the text to measure.
 * @returns the line count; zero for empty text.
 */
export declare function countLines(text: string): number;
/** One diff computation, as both of a tool's output callbacks need it. */
export interface DiffResult {
    /** The real added/removed counts, context excluded. */
    count: LineChangeCount;
    /** The changed regions the card renders — the changed lines only, no context. */
    diffs: FileDiff[];
}
/**
 * The diff for one tool result, computed once per result.
 *
 * Both callbacks of a tool must go through this rather than calling
 * {@link countLineChanges} and {@link computeHunkDiffs} separately: those two
 * would each run their own diff over the same texts, and the card and the message
 * would then be derived from two independent computations of the same thing.
 *
 * The three content arguments must describe `value` and must be the same on every
 * call for it — they are not part of the memo key, so a second call with different
 * texts or a different path silently returns the first call's answer. Every caller
 * passes the fields straight off the result (`v.path`, `v.before`, `v.after`),
 * which is what makes that safe; a caller that wants a different path must not
 * route it through here.
 *
 * The returned object is the cached one, shared by every call for this `value`, so
 * callers must treat it as read-only: mutating `count` or `diffs` here would be
 * visible to the other callback of the same result. Both callers read one field
 * each and neither writes, which is why this returns the cached object rather than
 * a copy. (The harness itself is not a concern — it deep-copies whatever a
 * projection returns before storing it.)
 *
 * @param value - the tool result value, used as the memo key.
 * @param path - the model-facing path stamped on every diff.
 * @param before - the file text before the change.
 * @param after - the file text after the change.
 * @returns the counts and the changed regions, sharing one diff. Read-only.
 */
export declare function diffForResult(value: object, path: string, before: string, after: string): DiffResult;
