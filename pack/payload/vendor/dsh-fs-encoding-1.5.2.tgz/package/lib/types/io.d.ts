/**
 * Read/write orchestration: the one path every tool goes through.
 *
 * Reads go through `ctx.fs.readBytes` (the public byte seam) and admission in
 * `encoding-state`; writes go through the fence in `sandbox` and the byte
 * publisher in `byte-writer`. Keeping both directions in one module is what
 * makes the round-trip auditable: there is exactly one place that decides an
 * encoding and exactly one place that turns text back into bytes.
 *
 * @module dsh-fs-encoding/io
 */
import type { Context } from "@deepseek-ai/cordis";
import { type FsTarget, type FsVersion } from "@deepseek-ai/dsh-fs";
import type { SandboxExecutionPolicy } from "@deepseek-ai/dsh-sandbox";
import type { ToolExecution } from "@deepseek-ai/dsh-tools";
import { type FileEncodingState } from "./encoding-state.js";
import type { EncodingSandbox } from "./sandbox.js";
/** A decoded file plus everything a caller needs to report on it. */
export interface ReadOutcome {
    /** The text, with any BOM already removed and the file's own line endings intact. */
    text: string;
    /** The resolved target the text came from. */
    target: FsTarget;
    /** The encoding recorded for this read. */
    state: FileEncodingState;
    /** An out-of-band note for the model (auto-guess provenance), never file content. */
    footer?: string;
}
/**
 * The canonical key a target's encoding state is memoized under.
 *
 * Exported because the undo history is keyed by the same identity: a record
 * written under one key and looked up under another would silently never match,
 * and the undo would report "no history" for a file it just edited.
 *
 * @param target - the resolved target.
 * @returns its canonical key.
 */
export declare function keyOf(target: FsTarget): string;
/**
 * The session bucket a call's encoding state belongs to.
 *
 * Derived from the calling execution so two sessions never share a record: one
 * session's encoding choice must not silently decide how another session
 * decodes, and an agentless caller gets its own bucket rather than a global one.
 *
 * @param exec - the calling execution, when there is one.
 * @returns the bucket key.
 */
export declare function sessionKeyFor(exec: ToolExecution | undefined): string;
/**
 * Map a thrown `ctx.fs` error onto the model-facing vocabulary.
 *
 * The built-ins leak raw `FsError`s for the read path; these tools keep the
 * same codes so a model that learned them from the built-ins is not surprised.
 *
 * @param error - the thrown error.
 * @param displayPath - the path as the model wrote it.
 * @throws always — the mapped error.
 */
export declare function mapReadError(error: unknown, displayPath: string): never;
/**
 * Read a file's bytes, decode them under the plugin's admission rules, record
 * the encoding for the coming save, and record the observation.
 *
 * The version is captured BEFORE the bytes so a concurrent change between the
 * two shows up as a version mismatch on the next save rather than as a memo
 * that authorizes a write against content the model never saw. For the same
 * reason the observation is emitted at that pre-read version: recording a
 * newer version than the content actually served would let a write pass the
 * guard while overwriting content the model never saw. Recording the older one
 * fails closed — the write is refused and the model re-reads.
 *
 * @param ctx - the plugin's context (for `ctx.fs`).
 * @param path - the path as the model wrote it, resolved against `cwd`.
 * @param cwd - the session workspace root.
 * @param opts - the calling execution, an optional explicit encoding, and
 *   whether this read counts as the model observing the file.
 * @returns the decoded text, its target, and the recorded state.
 */
export declare function readFile(ctx: Context, path: string, cwd: string, opts?: {
    signal?: AbortSignal | undefined;
    encodingHint?: string | undefined;
    exec?: ToolExecution | undefined;
    /**
     * Whether to record this read as the session's observation of the file.
     * Defaults to `true`: a model-facing read must arm the read-before-write
     * gate. Internal reads that exist only to build a diff pass `false`, so
     * they cannot silently satisfy a gate the model never did.
     */
    observe?: boolean | undefined;
    /**
     * Whether to store the encoding this read derived as the session's record
     * for the file. Defaults to `true`.
     *
     * Separate from {@link observe} because the two answer different questions
     * and the dangerous case is the one where they disagree. A presentation-only
     * read (a diff baseline) passes `observe: false` so it cannot arm the gate —
     * but if it still WROTE the encoding record, it would replace the session's
     * knowledge with whatever this read guessed, and that guess would then
     * authorize the coming save. After an eviction that is precisely the silent
     * re-encode the write guard refuses; the guard sees a record and stands
     * down. A read that is not allowed to speak for the session must not leave
     * a record behind either.
     */
    recordState?: boolean | undefined;
}): Promise<ReadOutcome>;
/** Everything a governed write needs from the calling tool. */
export interface WriteRequest {
    /** The resolved target to replace. */
    target: FsTarget;
    /** The complete new text, BOM-free and with the caller's line endings. */
    content: string;
    /** The calling execution. */
    exec: ToolExecution;
    /** The policy resolved for this call, or `undefined` on an unsandboxed backend. */
    policy: SandboxExecutionPolicy | undefined;
    /**
     * The encoding to CREATE the file in, when the caller named one.
     *
     * Only consulted for a file that does not exist. An existing file's recorded
     * encoding always wins, and the calling tool refuses the argument outright in
     * that case, so the two rules cannot disagree — see `tool-write`.
     */
    newFileEncoding?: string | undefined;
    /**
     * The text this write REPLACES, LF-normalized and BOM-free, when the caller
     * already has it. Providing it is what makes the write undoable.
     *
     * Optional because two callers legitimately lack it: a file being created has
     * no previous content, and a caller that could not read the old bytes (a
     * binary file, a permission failure) must not fabricate them. Absent means
     * "no undo point", which is the honest answer rather than a guess.
     */
    previousText?: string | undefined;
    /**
     * The encoding state to RESTORE, when this write is an undo.
     *
     * Used instead of the session's recorded state, and it disables
     * `normalizeToUtf8` for this call. Both halves matter:
     *
     * - The record may describe the bytes this write is replacing rather than the
     *   ones it must restore. With `normalizeToUtf8` on, the edit being undone
     *   migrated a legacy file to UTF-8, so the session's record says `utf8` while
     *   the file must go back to `gbk`. Encoding the undo from that record would
     *   leave the file as UTF-8 — the content reverted, the encoding not.
     * - Re-applying the migration would do the same thing by a different route:
     *   the migration is part of the edit being undone, so running it again would
     *   immediately re-convert what the undo just restored.
     */
    restoreState?: FileEncodingState | undefined;
}
/** What a governed write produced. */
export interface WriteOutcome {
    /** The version the write published, when the backend reports one. */
    version: FsVersion | undefined;
    /** The bytes actually written, for diagnostics and tests. */
    bytes: Uint8Array;
}
/**
 * Publish text to a file under the plugin's full guard sequence.
 *
 * The order is load-bearing and mirrors the built-ins exactly:
 *
 * 1. **Fence** — the per-call policy decides whether this target is writable,
 *    and returns the freshly canonicalized target to write.
 * 2. **Guard** — `fs/write-intent` (or `fs/edit-intent`) supplies the version
 *    the write must match, which is what makes a stale write fail instead of
 *    clobbering someone else's change.
 * 3. **Encode** — the recorded encoding is inverted, and an unmappable
 *    character fails the save before anything is published.
 * 4. **Publish** — bytes replace the file atomically.
 * 5. **Observe** — the new version is recorded so the next built-in tool sees a
 *    fresh observation rather than a stale one.
 *
 * Steps 1–3 all happen before step 4, so every failure mode leaves the file
 * untouched.
 *
 * @param ctx - the plugin's context.
 * @param sandbox - the fence and event gate.
 * @param req - the write request.
 * @param mode - which guard to take: `"write"` for a whole-file replace,
 *   `"edit"` for an in-place edit that additionally requires a prior read.
 * @returns what was written.
 */
export declare function writeFile(ctx: Context, sandbox: EncodingSandbox, req: WriteRequest, mode: "write" | "edit"): Promise<WriteOutcome>;
