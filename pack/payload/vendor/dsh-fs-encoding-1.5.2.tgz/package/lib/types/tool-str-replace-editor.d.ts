/**
 * The `str_replace_editor` compatibility tool.
 *
 * Registers under the name Anthropic's text-editor tool uses and the harness
 * shadows, so a model whose habits were formed around that tool — or a prompt
 * written for it — keeps working. Every command is routed through this plugin's
 * own IO, which is the whole point: the harness's version reads and writes UTF-8
 * text, so `str_replace` and `insert` corrupt any legacy-encoded file. Here they
 * decode under the file's recorded encoding and re-encode on save.
 *
 * Command semantics follow the harness (which follows Anthropic), deliberately:
 *
 * - `insert_line` inserts AFTER the named line, `0` being the top. See
 *   `insertAfterLine` for why the direction is not a free choice.
 * - `str_replace` requires a unique match and refuses otherwise. `replace_all` is
 *   accepted as an OPT-IN extension — omitting it reproduces the harness exactly.
 * - `create` refuses an existing file rather than overwriting it.
 * - `view` lists a directory (2 levels, hidden entries skipped) or shows a file
 *   with line numbers.
 * - `undo_edit` forwards to `undo_last_edit`'s implementation. The arguments are
 *   identical (`{path}`), so a second implementation of "undo" would only be a
 *   way for the two to disagree about what is undoable.
 *
 * @module dsh-fs-encoding/tool-str-replace-editor
 */
import type { Context } from "@deepseek-ai/cordis";
import type { EncodingSandbox } from "./sandbox.js";
/**
 * Build the `str_replace_editor` tool.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 */
export declare function buildStrReplaceEditorTool(ctx: Context, sandbox: EncodingSandbox): import("@deepseek-ai/dsh-tools").ToolDefinition;
