/**
 * Plugin configuration — `$DSH_HOME/plugins/dsh-fs-encoding/config.yaml` with
 * `DSH_FS_ENCODING_*` environment overrides on top.
 *
 * Deliberately a flat, hand-parsed YAML subset (scalars, inline arrays) rather
 * than a YAML dependency: the file holds only scalar keys, and a plugin that
 * shadows `read` should not add a parser to every session's boot path.
 *
 * @module dsh-fs-encoding/config
 */
/** Resolved, validated plugin configuration. */
export interface PluginConfig {
    /**
     * When `true`, a file that is not valid UTF-8 and carries no BOM is decoded
     * with the best-scoring allowlisted encoding instead of failing.
     *
     * Defaults to `false` (matching VS Code's `files.autoGuessEncoding`): a wrong
     * guess is invisible to the model and would then be written back under the
     * wrong encoding, so guessing stays opt-in.
     */
    autoGuessEncoding: boolean;
    /**
     * When `true`, a file in a non-Unicode code page (GBK, Big5, Shift-JIS, …) is
     * rewritten as UTF-8 on its first save, migrating it. When `false` the
     * recorded encoding is preserved byte-exactly.
     *
     * UTF-16 and UTF-32 are NOT migrated: they are already Unicode, differing only
     * in byte order, so converting them would change the storage without making
     * the file any more portable — and would break a consumer expecting UTF-16.
     */
    normalizeToUtf8: boolean;
    /** Encodings considered by `autoGuessEncoding` and listed in the error hint. */
    supportedEncodings: string[];
    /**
     * Encodings removed from the default guess set, when the user did not supply a
     * full {@link supportedEncodings} list.
     *
     * This exists so that "drop one encoding" does not force a user to write out
     * the whole list. Writing the list out would freeze today's set into the config
     * file, which is exactly what the commented-out default avoids: a later release
     * could no longer reach that deployment. A subtraction keeps the "follow the
     * shipped default, minus these" relationship, so additions still arrive.
     *
     * Ignored when `supportedEncodings` is set explicitly — an explicit list is
     * the user's whole answer, and subtracting from it would be second-guessing.
     *
     * Config-file only: there is deliberately no environment counterpart. The
     * environment names a whole set, so an env-level exclusion list would have no
     * coherent meaning when the file supplies the list instead.
     */
    excludeEncodings: string[];
    /** Inclusive byte cap for a whole-file read; larger files fail loud. */
    maxFileBytes: number;
}
/** Commented YAML written on first load so the file is discoverable and editable. */
export declare const DEFAULT_CONFIG_YAML: string;
/** Directory holding this plugin's shared home (config, caches). */
export declare function configDir(): string;
/**
 * Load the effective configuration, cached by config-file mtime and by the
 * environment values that participate.
 *
 * A malformed or unreadable config file degrades to the defaults rather than
 * failing a tool call — the file is a convenience, not a contract.
 *
 * `supportedEncodings` is intentionally absent from the generated config, so
 * "not set" means "whatever this version ships". A key that IS present wins,
 * which is what makes an explicit choice stick. There is no migration step and
 * none is needed: adding an encoding in a later release reaches every deployment
 * that never overrode the list, and never touches a deployment that did.
 *
 * @returns the merged, validated configuration.
 */
export declare function loadConfig(): PluginConfig;
/**
 * Materialize the commented default config when absent.
 *
 * Idempotent (`wx`), so a concurrent boot cannot clobber a user's edits, and
 * best-effort: a failure is never fatal to the plugin.
 *
 * An existing file is NEVER rewritten. An earlier revision tried to "retire" a
 * `supportedEncodings` line inherited from an older template, which meant
 * reading the user's file as UTF-8 and writing it back — that silently transcoded
 * a non-UTF-8 config to replacement characters, converted its CRLF line endings
 * to LF, and, when the value happened to be truncated to a template default,
 * deleted an encoding the user had added. Nothing in this file is worth that
 * risk: the plugin works from compiled defaults, and the template now ships the
 * key commented out, so a fresh install never pins the set in the first place.
 */
export declare function ensureDefaultConfig(): Promise<void>;
/** Drop the memoized configuration. Test seam. */
export declare function resetConfigCache(): void;
