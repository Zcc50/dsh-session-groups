/**
 * The encoding-governed `insert` tool: add lines at a line number.
 *
 * The one capability the plugin's `read` / `write` / `edit` set was missing. A
 * literal-match edit can only insert where it can quote surrounding text, which is
 * awkward for the common "add a line at the top" or "append after the imports" —
 * the model has to read the file first and reproduce a line exactly. Addressing by
 * line number removes that.
 *
 * `insert_line` follows Anthropic's text-editor semantics, which is also what the
 * harness's `str_replace_editor` uses: the text goes AFTER the named line, `0`
 * means the very top, and `lines.length` appends. See `insertAfterLine`.
 *
 * The file is decoded under its recorded encoding and re-encoded on save, so
 * inserting into a GBK file leaves it a GBK file — the harness's `insert` command
 * cannot do that, because it reads and writes UTF-8 text.
 *
 * @module dsh-fs-encoding/tool-insert
 */
import type { Context } from "@deepseek-ai/cordis";
import type { EncodingSandbox } from "./sandbox.js";
/**
 * Build the encoding-governed `insert` tool.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 */
export declare function buildInsertTool(ctx: Context, sandbox: EncodingSandbox): import("@deepseek-ai/dsh-tools").ToolDefinition;
