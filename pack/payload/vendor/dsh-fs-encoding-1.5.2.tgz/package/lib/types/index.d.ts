/**
 * dsh-fs-encoding — encoding-governed `read` / `write` / `edit` for DeepSeek
 * Harness.
 *
 * The harness's filesystem seam is UTF-8-only by contract: it decodes with a
 * strict `TextDecoder` (so a GBK file is `FS_NOT_TEXT`), its `TextDecoder`
 * swallows a leading UTF-8 BOM, and its only mutation entry point takes a
 * `string` and always encodes it as UTF-8 — there is no `writeBytes`. The
 * practical result is that a GBK file cannot be read, and editing a BOM-carrying
 * file silently drops the BOM.
 *
 * This plugin closes that gap from the tool layer. It shadows the three
 * model-facing tools on each agent's OWN scope layer (nearest layer wins in
 * dsh's tool registry), reads through the public `ctx.fs.readBytes` byte seam,
 * and publishes bytes itself. It does NOT replace `ctx.fs`, and it reproduces
 * every guarantee `ctx.fs.writeText` would have provided — the sandbox fence,
 * the `fs/write-intent` / `fs/edit-intent` version guards, and the
 * `fs/observed` observation — using only public seams, so the built-in tools
 * keep working against the same state.
 *
 * INSTALL POINT: the per-agent install hangs off BOTH `agent/created` and
 * `agent/session-start`, because `agent/session-start` is absent from the
 * `0.1.6-alpha` line onward while `agent/created` exists on every supported
 * line — see {@link onAgentEvent}. Whichever fires first installs; the other is
 * a no-op.
 *
 * CONFLICT: any plugin that shadows `read` / `write` / `edit` on the same layer
 * collides with this one, because registering a name twice in a layer throws.
 * The conflict is detected by letting the registry answer — the registration is
 * what actually fails — and the rejection is reported with the tool name it
 * names. Whatever landed before the failure is rolled back, so the install is
 * refused with an actionable message rather than leaving a half-registered set.
 *
 * Deliberately NOT probed up front with `ctx.tools.get(name)`: without a scope
 * argument that reads the GLOBAL view, and the global layer is precisely the
 * one this plugin shadows on purpose. The built-in `read` / `write` / `edit`
 * sit there in every profile that mounts `tool-fs` host-plane (`dsh-headless`,
 * the SDK and ACP profiles), so treating an inherited name as a conflict would
 * refuse an install that would have succeeded — and silently, because the
 * refusal is only logged.
 *
 * The message deliberately names no other plugin. Which one is installed is the
 * operator's to determine — a hard-coded name would be wrong whenever a
 * different plugin holds the layer, and pointing at a specific project reads as
 * a judgement about it rather than a statement about this one.
 *
 * @module dsh-fs-encoding
 */
import type { Context } from "@deepseek-ai/cordis";
import type { FileSystem } from "@deepseek-ai/dsh-fs";
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "dsh-fs-encoding";
/**
 * Services the per-agent install touches: `tools` and `systemPrompt` for the
 * shadow registrations, `fs` for the byte seam.
 *
 * Cordis refuses property access to an undeclared service, and the failure is
 * invisible from the model's side — the install throws at session-start and the
 * session quietly runs the built-ins — so this list must stay complete.
 */
export declare const inject: string[];
/**
 * Mount the bundle: materialize the default config, publish the decoding
 * service, then install the tools per agent.
 *
 * @param rootCtx - the host-plane plugin context.
 */
export declare function apply(rootCtx: Context): void;
export { READ_DESCRIPTION, WRITE_DESCRIPTION, EDIT_DESCRIPTION, readSectionText, writeSectionText, editSectionText, } from "./prompts.js";
export { FS_ENCODING_SERVICE, FsEncodingService, isFsEncodingService, provideFsEncoding, type FsDecodeOptions, type FsDecodeRefusal, type FsDecodeResult, type RecordedEncoding, } from "./service.js";
export type { DecodeProvenance } from "./encoding-state.js";
export type { FileSystem };
