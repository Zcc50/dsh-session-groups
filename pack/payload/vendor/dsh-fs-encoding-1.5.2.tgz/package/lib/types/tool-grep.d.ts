/**
 * The encoding-governed `grep` tool.
 *
 * Contract-compatible with the built-in `grep` (same `pattern` / `path` /
 * `include` arguments, same `{ matches: [{ path, lineNumber, line }] }` result
 * shape, same search card, same over-cap spill recovery) with one difference: a
 * file in a legacy code page is searched and reported as TEXT rather than as
 * unreadable bytes.
 *
 * ## What the built-in does, and why it is not enough
 *
 * The built-in runs ripgrep once and prints what comes back. Two failures follow
 * from that, and the second is the serious one:
 *
 * - Matching lines in a non-UTF-8 file are reported as the literal string
 *   `(line is not valid UTF-8)`. The content is right there in the file and the
 *   model is told it cannot be shown.
 * - A non-ASCII pattern is matched against RAW BYTES, so it cannot match a file
 *   whose bytes are not UTF-8. Searching a GBK file for a Chinese word returns
 *   ZERO matches — no error and no placeholder. The model reads that as "not
 *   present" when the truth is "not searched".
 *
 * ## The shape of the fix
 *
 * Ripgrep stays the engine; this tool drives it twice when needed. Pass 1 is the
 * built-in's own call, and everything it already decoded is adopted verbatim.
 * Only files that produced an undecodable row go to pass 2, where each is
 * re-searched with an encoding chosen per file. See
 * {@link module:dsh-fs-encoding/grep-search} for the measurements behind that
 * choice — in particular why a JavaScript-side search was rejected (25x slower,
 * and it would silently change the pattern language).
 *
 * ## Registration is conditional, deliberately
 *
 * The tool is registered only when `ctx.subprocess` is present. It is read with
 * `ctx.get` and NOT declared in `inject`, because cordis deactivates the WHOLE
 * plugin when any injected service is missing — measured: the fiber reports
 * `epoch: __INACTIVE__`, `apply` never runs, and mounting the service later does
 * not activate it either. Declaring `subprocess` would therefore trade this
 * tool's availability for `read` / `write` / `edit` working at all, in any
 * deployment that mounts the search plugin without the subprocess seam.
 *
 * So a missing `subprocess` costs exactly the thing it should: this plugin
 * leaves `grep` to the built-in, and the other five tools are unaffected.
 *
 * @module dsh-fs-encoding/tool-grep
 */
import type { Context } from "@deepseek-ai/cordis";
import type { SearchKit } from "./search-kit.js";
/**
 * The subset of `ctx.subprocess` this tool calls.
 *
 * Structural rather than imported, so the plugin needs no type dependency on
 * `@deepseek-ai/dsh-subprocess` for a service it reaches opportunistically. The
 * shape is the one the built-in package's own spawn helper relies on, and
 * {@link subprocessOf} is what proves it at runtime before any call is made.
 */
interface SpawnOutcome {
    exitCode: number | null;
    signal: string | null;
}
interface CollectedStream {
    readFrom(offset: number): {
        text: string;
        lossy: boolean;
    } | undefined;
}
interface SpawnHandle {
    done: Promise<SpawnOutcome>;
    collected: {
        stdout?: CollectedStream;
        stderr?: CollectedStream;
    };
}
interface SubprocessLike {
    spawn(spec: {
        argv: readonly string[];
        cwd: string;
        stdio: {
            stdin: "ignore";
            stdout: {
                maxBytes: number;
            };
            stderr: {
                maxBytes: number;
            };
        };
        graceMs: number;
        signal?: AbortSignal | undefined;
    }): SpawnHandle;
}
/**
 * Read the subprocess seam, or `undefined` when this deployment has none.
 *
 * A capability check rather than a truthiness test: `ctx.get` answers with
 * whatever object holds the name, and calling `spawn` on a foreign one would
 * throw inside the tool. Reading it fresh on every call is deliberate — each
 * `ctx.get` returns a NEW tracing proxy over the same service (measured:
 * `root.get("subprocess") !== root.get("subprocess")`), so caching the object or
 * comparing it by identity would both be wrong.
 *
 * @param ctx - the plugin context.
 * @returns the seam, or `undefined`.
 */
export declare function subprocessOf(ctx: Context): SubprocessLike | undefined;
/**
 * Build the encoding-governed `grep` tool.
 *
 * @param ctx - the plugin's host context.
 * @param kit - the loaded search toolkit; the caller has established it is usable.
 * @param subprocess - the validated seam; the caller has already established it exists.
 */
export declare function buildGrepTool(ctx: Context, kit: SearchKit, subprocess: SubprocessLike): import("@deepseek-ai/dsh-tools").ToolDefinition;
/** The tool name, so `index.ts` and the tests share one spelling. */
export declare const GREP_TOOL_NAME = "grep";
export {};
