/**
 * Line-ending helpers and the UTF-8 BOM marker.
 *
 * The harness's own `fs-local.editText` already round-trips line endings for
 * UTF-8 files. This plugin must do the same thing itself because it writes
 * bytes directly, so the logic lives here as pure functions shared by the read
 * and save paths.
 *
 * @module dsh-fs-encoding/line-endings
 */
/** The three line terminators this plugin preserves. */
export type LineEnding = "\r\n" | "\n" | "\r";
/** U+FEFF as a string — the character form of the UTF-8 BOM. */
export declare const UTF8_BOM = "\uFEFF";
/** The UTF-8 BOM's three bytes. */
export declare const UTF8_BOM_BYTES: Uint8Array<ArrayBuffer>;
/**
 * Classify a text's dominant line ending.
 *
 * The FIRST terminator wins, matching the harness's own detection: a file whose
 * first break is CRLF is treated as CRLF throughout, so a stray lone LF later
 * in the file does not flip the whole file's style.
 *
 * @param content - the decoded text.
 * @returns the dominant line ending; LF for empty or break-free content.
 */
export declare function detectEnding(content: string): LineEnding;
/**
 * Normalize every terminator to LF.
 *
 * @param text - the text to normalize.
 * @returns the text with no CR characters left.
 */
export declare function toLF(text: string): string;
/**
 * Rewrite LF terminators back to the recorded style.
 *
 * @param text - LF-normalized text.
 * @param ending - the style to restore.
 * @returns the text with the requested terminators.
 */
export declare function restoreEndings(text: string, ending: LineEnding): string;
/**
 * Split a leading U+FEFF off a decoded string.
 *
 * @param content - the decoded text.
 * @returns the BOM (or `""`) and the remaining text.
 */
export declare function stripBOM(content: string): {
    bom: string;
    text: string;
};
/**
 * Split text into the lines the model sees: a trailing newline does not open a
 * line.
 *
 * Only `""` and a lone `"\n"` collapse to a single empty entry; a longer run of
 * terminators is one empty entry per terminator, so `"\n\n"` is two entries.
 *
 * @param text - the text to split.
 * @returns one entry per visible line.
 */
export declare function splitLines(text: string): string[];
