/**
 * Byte-level atomic file replacement.
 *
 * The harness's `FileSystem` seam has `readBytes` but no `writeBytes`: its only
 * mutation entry point takes a `string` and encodes it as UTF-8 internally. To
 * preserve a file's original encoding this plugin must publish raw bytes, and
 * it must do so without losing the guarantees `ctx.fs.writeText` provides —
 * atomicity, permission preservation, and hard-link safety.
 *
 * That is what this module is: `ctx.fs.writeText`'s storage mechanics,
 * reimplemented over `Uint8Array`. It is deliberately the ONLY place in the
 * plugin that touches `node:fs` for writing.
 *
 * @module dsh-fs-encoding/byte-writer
 */
/**
 * Replace `path` with `bytes` atomically.
 *
 * Writes a random-suffix sibling opened with exclusive create, then renames it
 * over the target, so a reader observes either the complete old content or the
 * complete new content — never a partial write. Three details are load-bearing
 * and are each a bug that was already paid for once in the harness's own
 * implementation:
 *
 * 1. **Hard links are written in place.** `rename` would give the target a new
 *    inode and silently detach every other name pointing at the old one.
 * 2. **Permission bits are carried over** by `chmod`-ing the temp file before
 *    the rename, so a private file does not become world-readable.
 * 3. **Windows `EPERM`/`EACCES`/`EBUSY` falls back to an in-place write.**
 *    Windows refuses to rename over a file another process holds open; the
 *    content still lands, just without the atomicity guarantee.
 *
 * @param path - absolute path to replace.
 * @param bytes - the complete new content.
 * @throws whatever the underlying filesystem raises, after cleaning up the temp file.
 */
export declare function writeBytesAtomic(path: string, bytes: Uint8Array): Promise<void>;
/** Test seam: forget which directories were swept. */
export declare function resetSweepCache(): void;
