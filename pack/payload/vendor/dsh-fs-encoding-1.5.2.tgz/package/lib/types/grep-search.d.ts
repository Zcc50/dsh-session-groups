/**
 * Encoding-aware search core for the shadowed `grep` tool.
 *
 * The built-in `grep` runs the packaged ripgrep binary once and trusts its
 * `--json` output. That is enough for a UTF-8 repository and wrong for every
 * other one, in two distinct ways:
 *
 * 1. **Placeholders.** ripgrep emits `lines.text` only when a matched line is
 *    valid UTF-8 and falls back to base64 `lines.bytes` otherwise. The built-in
 *    parser replaces that with the literal string `(line is not valid UTF-8)`,
 *    so a GBK file's matching lines are reported as unreadable rather than
 *    shown.
 * 2. **Silent misses.** A non-ASCII pattern is matched against the file's RAW
 *    BYTES. The pattern's UTF-8 byte sequence cannot occur in a GBK file, so a
 *    search for a Chinese word in a GBK file returns nothing at all — no error,
 *    no placeholder, just a smaller result. This is the more dangerous half:
 *    the model cannot tell "not present" from "not searched".
 *
 * ## Why this is not a re-implementation of the search
 *
 * The obvious fix — decode every candidate file in JavaScript and match with a
 * `RegExp` — was measured and rejected. On 200 files / 15.4 MB it costs
 * ~1200 ms against ripgrep's 45 ms, and 96% of that is the per-file encoding
 * detection, not the matching (regex: 32 ms, file IO: 19 ms). Worse, it would
 * silently change the pattern language: `(?i)` and `(?s)` are ripgrep syntax
 * that throws in JavaScript, `\p{Greek}` needs a `u` flag, and `\w` does not
 * mean the same set.
 *
 * So ripgrep stays the search engine and this module adds the two things it
 * cannot do by itself:
 *
 * - A **per-file** encoding decision, because `--encoding` is a whole-invocation
 *   flag. Measured: telling ripgrep `--encoding=gbk` over a mixed directory
 *   makes it MISS the UTF-8 files and mojibake them when it does match
 *   (`alpha 閰嶇疆椤� port=8080`), so the flag cannot simply be passed through.
 * - A **byte-preserving** parse, because the built-in one discards
 *   `lines.bytes` and the raw bytes are unrecoverable afterwards.
 *
 * ## The two-pass shape
 *
 * Pass 1 runs ripgrep once with no `--encoding`, exactly as the built-in does.
 * Every line it already decoded is adopted as-is — that is most lines in most
 * repositories, and costs nothing extra. Only the files that produced at least
 * one `lines.bytes` row are carried into pass 2.
 *
 * Pass 2 decides one encoding per such file and re-runs ripgrep for that file
 * alone with `--encoding=<label>`, which makes ripgrep transcode the whole file
 * and emit `lines.text` for every row. Measured: the cost is bounded by the
 * number of files that actually contained a non-UTF-8 matched line, which is
 * zero for an ASCII search over a UTF-8 repository.
 *
 * ## How a page PROVES it decoded a file
 *
 * ripgrep transcodes a file with the page it was given and only then matches, so
 * a submatch holding a non-ASCII character is one that page's own mapping
 * produced. That is a proof about the file, and {@link provedFiles} keeps it.
 *
 * What is NOT a proof is a match, which is what this module used to assume.
 * A pattern that also holds an ASCII alternative — `配置|read` — matches under
 * EVERY page, because `read` is the same bytes in all of them, and the union
 * then carried one page's mojibake for a file another page had decoded.
 * Measured on a directory holding the same text as UTF-8 and as GBK, `配置|read`
 * returned four claims per line from four pages, agreeing on nothing. An ASCII
 * submatch is therefore no evidence at all, which is what rules that alternative
 * out without this module having to parse the pattern's syntax.
 *
 * The evidence deliberately is NOT "a character the pattern holds". The two
 * differ wherever the pattern's syntax keeps its characters out of the matched
 * text: `[一-龥]` matches Chinese without ever spelling `一` or `龥`, and
 * `(?i)привет` matches `ПРИВЕТ`, whose characters the pattern does not hold.
 * Measured, both proved nothing under that older rule and left a GBK file
 * unreported — the silent miss this tool exists to remove. U+FFFD is excluded
 * for the opposite reason: a decoder SYNTHESISES it for a byte it cannot map, so
 * it is evidence against a page rather than for it.
 *
 * The unit is the FILE rather than the line, because `--encoding` transcodes the
 * whole file in one pass: one proving character makes every row of that file
 * trustworthy — including a row whose own match was the ASCII alternative.
 * Measured on a GBK file whose line 1 is `# 端口配置` and whose line 2 is the
 * plain-ASCII `PORT=8080 read this`, the gbk run proves the file on line 1 and
 * both rows come out decoded.
 *
 * @module dsh-fs-encoding/grep-search
 */
import type { Context } from "@deepseek-ai/cordis";
import type { FsTarget, FsVersion } from "@deepseek-ai/dsh-fs";
import type { ToolExecution } from "@deepseek-ai/dsh-tools";
import type { PluginConfig } from "./config.js";
/**
 * One matched line as ripgrep reported it, before any decoding.
 *
 * Exactly one of {@link text} / {@link bytes} is present, and which one is a
 * PER-LINE fact rather than a per-file one: ripgrep emits `text` for a line that
 * happens to be valid UTF-8 and `bytes` for one that is not. Measured on a
 * single GBK file: `PORT=8080` arrives as text while
 * `PORT=9090  # 配置项 端口` arrives as bytes.
 */
export interface RawMatch {
    /** Path exactly as ripgrep printed it (absolute or relative to the spawn cwd). */
    path: string;
    /** 1-based line number. */
    lineNumber: number;
    /** The line as UTF-8 text, when ripgrep could represent it. */
    text?: string;
    /** The line's raw bytes, when ripgrep could not. */
    bytes?: Uint8Array;
    /**
     * Whether any submatch on this line holds a non-ASCII character.
     *
     * This is what makes a page's claim checkable. `lines.text` says what the page
     * decoded the line INTO, which says nothing about whether it decoded it
     * CORRECTLY — under a wrong page every byte still decodes to something. A
     * submatch is different in kind: a page can only put a NON-ASCII character into
     * a matched span by mapping the file's bytes onto it. See {@link provedFiles}.
     *
     * Reduced to a boolean HERE rather than kept as texts, because that is the only
     * thing any caller asks of it and the texts are not free: measured at the 20 MB
     * stdout cap, retaining them took the heap from 7.9 MB to 17.5 MB on searches
     * that never read them. Deferring the parse behind a per-row closure was
     * measured WORSE still — 41.3 MB, because the closure costs more than the
     * strings and pins the raw record against collection. One boolean is the shape
     * that costs nothing on the three parse sites that ignore it.
     */
    submatchEvidence: boolean;
}
/**
 * A match that has been decoded, or one that could not be.
 *
 * The undecodable case is deliberately a VALUE rather than an omission. The
 * built-in tool drops the bytes and prints a placeholder that says nothing about
 * what to do next; here the placeholder carries the candidate encodings, so the
 * model can re-read the file and learn the answer.
 */
export interface DecodedMatch {
    /** Display path, workdir-relative where possible. */
    path: string;
    /** 1-based line number. */
    lineNumber: number;
    /** The decoded line, trailing newline removed. */
    line: string;
}
/**
 * The `--encoding` label for a canonical encoding name.
 *
 * @param encoding - canonical identifier, e.g. `shift_jis`.
 * @returns the ripgrep label, or `undefined` when ripgrep cannot search it.
 */
export declare function rgLabelFor(encoding: string): string | undefined;
/**
 * Whether a pattern can only match after ripgrep has transcoded a file.
 *
 * This is the switch between the tool's two search strategies, and it exists
 * because of a measured property of ripgrep: it matches the pattern against the
 * file's bytes and only then decides how to report the line. A pattern that is
 * pure ASCII is byte-identical in every encoding this plugin supports, so the
 * default call finds it everywhere — in a GBK file just as in a UTF-8 one. A
 * pattern with ANY non-ASCII character is a UTF-8 byte sequence that cannot
 * occur in a file in another encoding, so the default call misses such files
 * ENTIRELY: measured, `--regexp=配置项` over a GBK file returns zero matches,
 * with no error and no placeholder.
 *
 * That asymmetry is what makes the tool's two passes necessary rather than
 * merely an optimisation, and it is the reason this predicate — not a
 * performance heuristic — decides which strategy runs.
 *
 * @param pattern - the model-supplied regular expression.
 * @returns whether the pattern holds a character outside the ASCII range.
 */
export declare function needsTranscodedSearch(pattern: string): boolean;
/**
 * The encodings that could possibly spell this pattern.
 *
 * A cheap and exact narrowing of the sweep, from the same property that makes
 * the sweep work: ripgrep transcodes the file to UTF-8 and THEN matches, so a
 * pattern character the candidate encoding cannot represent can never appear in
 * its output. Measured over the seven legacy pages: `配置项` is representable
 * only by `gbk` (so six of the seven runs are skipped), while `Привет` is
 * representable by all seven and the full sweep runs.
 *
 * The comparison is a round trip rather than an `encodingExists` check, because
 * the question is not whether the codec knows the page but whether the page can
 * hold these particular characters — `iconv-lite` silently substitutes `?` for
 * a character a page lacks.
 *
 * @param pattern - the model-supplied regular expression.
 * @param encodings - the canonical names to filter.
 * @returns the subset that can represent the pattern, in the input order.
 */
export declare function encodingsForPattern(pattern: string, encodings: readonly string[]): string[];
/**
 * Parse ripgrep's `--json` NDJSON output, preserving BOTH line representations.
 *
 * This is the function the built-in package does not export, and its absence is
 * why this module exists at all: the built-in `parseGrepMatches` collapses a
 * `lines.bytes` row into the literal string `(line is not valid UTF-8)` at parse
 * time, and the raw bytes are gone by the time any post-processing hook could
 * see them.
 *
 * Malformed input is skipped rather than fatal. ripgrep's stdout is a transport
 * this module drives itself, so a line that is not JSON means a truncated read
 * (the output cap) rather than a caller error — failing the whole search there
 * would turn a partial result into no result, and the caller has the match count
 * to notice the difference.
 *
 * @param stdout - the complete raw stdout of one ripgrep run.
 * @returns every `match` record, in output order; non-match records are ignored.
 */
export declare function parseRgJson(stdout: string): RawMatch[];
/**
 * The files one page PROVED it decoded, from that page's submatches.
 *
 * A page proves a file when some submatch on one of that file's DECODED rows
 * holds a non-ASCII character. That is a proof rather than a correlation:
 * ripgrep transcodes the file with the page it was given and only then matches,
 * so a non-ASCII character in the matched span can only have come from that
 * page's mapping of the file's bytes.
 *
 * The reasoning this replaces treated a MATCH as the proof. It is not one, and
 * the difference is not subtle: a pattern holding an ASCII alternative —
 * `配置|read` — matches under every page, because `read` is the same bytes in all
 * of them. Measured on a directory holding the same text as UTF-8 and as GBK,
 * `配置|read` produced four contradicting claims per line, and the page that
 * happened to run last was the one on screen. An ASCII-only submatch is
 * therefore not evidence, which is what rules that alternative out.
 *
 * The evidence deliberately is NOT "a character the PATTERN holds". Those differ
 * wherever regex syntax keeps the pattern's characters out of the matched text,
 * and both directions were measured as silent misses on a GBK file that plainly
 * held the text: `[一-龥]` matches Chinese without ever spelling `一` or `龥`, and
 * `(?i)привет` matches `ПРИВЕТ`, whose characters the pattern does not hold.
 * See {@link hasSubmatchEvidence} for why U+FFFD is not evidence either.
 *
 * The granularity is the file, and it has to be: `--encoding` transcodes the
 * whole file in one pass, so one proving character makes every row of that file
 * trustworthy — including rows whose own match was an ASCII alternative. A file
 * the page did not prove contributes nothing, even if that page matched it.
 *
 * @param rows - the `match` rows one page's run produced, in output order.
 * @returns the paths of the files this page proved, in first-seen order.
 */
export declare function provedFiles(rows: readonly RawMatch[]): string[];
/** Which files produced at least one undecodable row, in first-seen order. */
export declare function filesNeedingDecoding(matches: readonly RawMatch[]): string[];
/**
 * The encoding this session has already recorded for a file, if any.
 *
 * The seam that makes grep agree with `read` instead of guessing independently.
 * `read` records what it established — including an explicit
 * `read({ encoding: "gbk" })`, which is the documented remedy for a legacy file
 * — and `io.ts` reuses that record as the hint on every later read. A search
 * that ignored it would report a placeholder for a file the session has already
 * decoded, and the model would have no way to tell that the answer was sitting
 * right there.
 *
 * Read-only, like everything on the search path: `getEncodingState` looks a
 * record up and writes nothing, so consulting it cannot arm the write gate.
 *
 * Staleness is checked with the same `isStale` comparison the write path uses,
 * so a record describing a file that has since changed on disk is discarded
 * rather than applied to different bytes.
 *
 * @param exec - the calling execution, which owns the session bucket.
 * @param target - the resolved target.
 * @param version - the version just observed for the file.
 * @returns the recorded encoding, or `undefined`.
 */
export declare function recordedEncodingHint(exec: ToolExecution, target: FsTarget, version: FsVersion | undefined): string | undefined;
/** The candidate encoding names from a refusal, best first. */
export declare function candidatesOf(error: unknown): string[];
/**
 * Merge pass-1 and pass-2 results into one ordered, deduplicated list.
 *
 * Deduplication is by `(path, lineNumber)` and pass 2 wins, because pass 2 read
 * the file later and under an encoding that actually decodes it. Without this a
 * file searched in both passes would report every matching line twice — pass 1
 * from its undecodable rows and pass 2 from its decoded ones.
 *
 * Ordering follows the built-in tool's: files in first-seen order, lines
 * ascending within a file. The first-seen order of a file is taken from whichever
 * pass saw it first, so a pass-2-only file (one that never matched in pass 1)
 * keeps a stable position rather than being appended arbitrarily.
 *
 * @param passes - the per-pass match lists, earliest pass first.
 * @returns the merged matches.
 */
export declare function mergeMatches(passes: readonly (readonly DecodedMatch[])[]): DecodedMatch[];
/**
 * The placeholder for a line that could not be decoded.
 *
 * Names the candidates when there are any, because that is the whole remedy: the
 * model can re-read the file with one of them and then search again. With no
 * candidates the honest statement is that the bytes are not text, so it says
 * that instead of offering an empty list.
 *
 * @param candidates - candidate encoding names, best first.
 */
export declare function placeholderFor(candidates: readonly string[]): string;
/**
 * Whether a byte buffer looks like binary rather than text in any encoding.
 *
 * Used only by the JavaScript fallback path, which — unlike ripgrep — has no
 * binary detection of its own. A NUL byte is the signal ripgrep itself uses.
 *
 * The check is deliberately NOT applied to UTF-32. Measured: a UTF-32LE file
 * begins `ff fe 00 00 63 00 00 00`, so a NUL test calls every UTF-32 file binary
 * — and UTF-32 is the one encoding this fallback exists to serve. The caller
 * therefore asks only for the encodings where a NUL really does mean binary,
 * which is all of them except the UTF-32 pair.
 *
 * @param bytes - the bytes to test.
 */
export declare function looksBinary(bytes: Uint8Array): boolean;
/**
 * Whether a NUL byte in these bytes means the content is not text.
 *
 * @param bytes - the bytes to test.
 * @param encoding - the encoding they are claimed to be in.
 */
export declare function binaryInEncoding(bytes: Uint8Array, encoding: string): boolean;
/**
 * The byte order a file's own LINE BREAKS name, if any.
 *
 * A NUL byte means two entirely different things depending on what the bytes
 * are, and this is the one fact that separates them from the bytes alone. UTF-16
 * stores U+000A as the pair `0a 00` (LE) or `00 0a` (BE) on a two-byte
 * character boundary, because every character occupies exactly one such pair; a
 * legacy code page stores it as the single byte `0a`, wherever it falls. So a
 * file whose line break sits on a character boundary is UTF-16, and a file whose
 * line break merely happens to be followed by a stray NUL is not.
 *
 * That distinction is what {@link readAndDecode} needs at its binary refusal,
 * and the reason it cannot use the NUL PARITY counts that answer the same
 * question elsewhere: measured over every offset a single stray NUL can occupy
 * in five legacy source files (995–999 placements each), the parity counts name
 * an order in 100% of them — one NUL is enough to make one parity win — while
 * the line-break alignment fires in 4.0%, on exactly the placements where the
 * NUL lands immediately after an even-offset break. The alignment is structural
 * rather than statistical: a genuine UTF-16 text file has every line break on a
 * character boundary, so it is named here in 100% of the measured cases.
 *
 * `undefined` means "not UTF-16 by this evidence", which is the answer that
 * keeps a legacy page's decode of a stray-NUL file. It is deliberately NOT
 * "this file is text": a UTF-16 file with no line break at all is undecidable
 * here, and the caller treats that the same way the search passes already do —
 * see `utf16ByteOrder`, which owns the full verdict and calls this for its
 * newline half so the two cannot drift apart.
 *
 * @param bytes - the file's bytes, or as much of them as were read.
 */
export declare function utf16NewlineOrder(bytes: Uint8Array): string | undefined;
/**
 * Search one already-decoded file with a JavaScript `RegExp`.
 *
 * The fallback for encodings ripgrep cannot be told about — UTF-32 is the only
 * one. Kept deliberately narrow: it changes the pattern language from ripgrep's
 * to JavaScript's (`(?i)` and `(?s)` throw here, `\p{Greek}` needs a `u` flag,
 * `\w` differs), so routing ordinary files through it would silently change
 * results. Measured cost is ~25x a ripgrep run, dominated by decoding.
 *
 * An invalid pattern is reported rather than swallowed, because the caller's
 * next move differs: a bad regex is the model's to fix, not a file to re-read.
 *
 * NOT called directly by the tool: a model-supplied pattern can backtrack
 * catastrophically, and this function cannot be interrupted once it starts, so
 * the tool runs it through {@link searchDecodedTextIsolated}. This stays the
 * single definition of the matching semantics — the worker executes THIS
 * function, transferred by its own source — which also means it must remain
 * self-contained. See {@link SEARCH_WORKER_SOURCE}.
 *
 * @param text - the decoded file content.
 * @param pattern - the model-supplied regular expression.
 * @param displayPath - the path to report on each match.
 * @returns the matching lines, or a thrown `SyntaxError` for a bad pattern.
 */
export declare function searchDecodedText(text: string, pattern: string, displayPath: string): DecodedMatch[];
/**
 * The error a pattern that outran {@link FALLBACK_SEARCH_BUDGET_MS} produces.
 *
 * A distinct type rather than a bare `Error` so the caller can tell a runaway
 * pattern from a broken search, and so the model-facing wording can say what to
 * do about it.
 */
export declare class PatternTimeoutError extends Error {
    constructor(budgetMs: number);
}
/**
 * {@link searchDecodedText} behind a hard-killable execution boundary.
 *
 * ## Why the boundary exists
 *
 * `RegExp` is synchronous and V8 will not interrupt it, so a model-supplied
 * pattern with nested quantifiers blocks the event loop for as long as the
 * backtracking takes. Measured on this exact code path: 26 characters of `a`
 * against `(a+)+b` blocked for 2.9 seconds and 40 characters exceeds the 2 s
 * budget outright — the cost doubles per character. The trailing character
 * matters: `(a+)+$` against a bare run of `a` finishes in 0 ms at any length,
 * because `$` matches before a final newline and the engine never backtracks.
 * Nothing cooperative helps once it does run, because nothing else gets to run:
 * `timeoutMs` and `exec.signal` are both promises to stop, and a blocked loop
 * cannot keep them.
 *
 * That is a defect of the HARNESS, not just of this call: the plugin shares the
 * process with the agent, so a stuck search freezes every other session in it.
 *
 * A worker thread is the one boundary Node offers that can actually be revoked.
 * Measured, `terminate()` on a thread deep in catastrophic backtracking settles
 * in 1 ms and leaves 0.000 CPU-seconds of residual burn, while the main thread
 * keeps servicing its timers (9 of 10 ticks during a full second of stuck
 * search). So this is elimination, not mitigation: the pattern can still be
 * catastrophic, it just cannot hold the loop.
 *
 * ## What it does NOT change
 *
 * Matching semantics are untouched — the worker runs {@link searchDecodedText}
 * itself, and the differential over the fallback path's whole shape space (CRLF,
 * `^`/`$` at EOF, empty lines, lone CR, NUL, 50 KB lines, non-ASCII patterns,
 * `\w`/`\d`/classes) is identical line for line. An uncompilable pattern still
 * arrives as a real `SyntaxError`, so the caller's `patternError` mapping is
 * unchanged.
 *
 * The cost is one worker per file, measured at ~15 ms including startup. That is
 * paid only for UTF-32 files, which is what this path exists for.
 *
 * @param text - the decoded file content.
 * @param pattern - the model-supplied regular expression.
 * @param displayPath - the path to report on each match.
 * @param options - the abort signal, and the budget override.
 * @returns the matching lines.
 * @throws `SyntaxError` when the pattern does not compile, matching
 *   {@link searchDecodedText}'s own contract.
 * @throws {@link PatternTimeoutError} when the budget is exhausted.
 * @throws when the caller aborts.
 */
export declare function searchDecodedTextIsolated(text: string, pattern: string, displayPath: string, options?: {
    signal?: AbortSignal | undefined;
    timeoutMs?: number | undefined;
}): Promise<DecodedMatch[]>;
/**
 * Whether a file's bytes are strict UTF-8 TEXT, which settles its encoding.
 *
 * A file that passes this test has exactly ONE correct reading, and it is the
 * strict pass's. Every legacy page's decode of it is mojibake by construction —
 * the bytes are already text, so re-reading them through another page can only
 * corrupt them. That makes this the discriminator the sweep's proof rule needs,
 * and it is the same rule `read` applies: `encoding-state` tests strict UTF-8
 * deterministically, BEFORE any guessing, and a file that passes never reaches
 * the heuristic at all.
 *
 * Why the proof rule needs it. A page "proves" a file by producing a non-ASCII
 * character in a submatch, and a UTF-8 file's bytes satisfy that under pages the
 * file was never in: measured, this repository's `LICENSE` under `[一-龥]` was
 * claimed by 4 pages, and a valid-UTF-8 file whose only non-ASCII character was
 * an em-dash came back as the mojibake `// note 鈥� dash only` — the em-dash's
 * bytes decode to CJK under `gbk`. 57 files of this repository alone were
 * affected. The `strictClean` filter at the call site cannot catch these: it
 * covers lines the strict pass MATCHED, and the bug lives precisely on the lines
 * it did not match (a file with no CJK has no `[一-龥]` line to match).
 *
 * The NUL test is not optional. Every byte pair of an ASCII-only UTF-16 file is
 * `xx 00`, and U+0000 is a legal code point, so such a file IS valid UTF-8 by
 * this test — measured. Without the NUL half the rule would void the claims for
 * a UTF-16 file that legitimately holds the text, which is the one family the
 * sweep exists to serve for BOM-less files. `looksBinary` is the same predicate
 * `readAndDecode` uses at its own refusal.
 *
 * Never throws: an unreadable path answers `false`, so the claim stands and the
 * ordinary paths decide it — this filter may only ever REMOVE a claim it can
 * prove wrong, never fail a search.
 *
 * A file over the read cap is answered from its bytes rather than refused. The
 * cap makes `readBytes` THROW instead of returning a prefix, and reading that
 * throw as "not plain UTF-8" is what let the mojibake above survive on exactly
 * the files this filter exists for: measured, a valid-UTF-8 file of 11.5 MB
 * whose only non-ASCII character was an em-dash still came back as
 * `// note 鈥� dash only` under the default cap. A prefix cannot settle this
 * question — one malformed sequence or one NUL ANYWHERE refutes it, and the
 * prefix that happened to be clean is not the file — so the bytes are streamed
 * instead, in windows bounded by the same cap. See {@link plainUtf8OfFile}.
 *
 * @param ctx - the plugin context, for `fs`.
 * @param exec - the calling execution, for the abort signal.
 * @param path - the path as ripgrep printed it.
 * @param config - the deployment's admission config, for the read cap.
 * @param cwd - the search's spawn directory, which is what ripgrep printed
 *   `path` relative to.
 * @returns whether the bytes are strict UTF-8 text with no NUL.
 */
export declare function isPlainUtf8Text(ctx: Context, exec: ToolExecution, path: string, config: PluginConfig, cwd: string): Promise<boolean>;
/**
 * What {@link readAndDecode} found for one file.
 *
 * A refusal is a VALUE that carries its reason rather than an omission, because
 * the reason is the whole remedy: an admission error holds the candidate
 * encodings the caller's placeholder names. Dropping it there meant reading the
 * file a second time and admitting it again to get the list back — a whole-file
 * read plus a whole-file admission, measured at ~96% of the cost of a decode
 * pass, spent to reproduce an answer the first call already had.
 *
 * `error` is `undefined` for the refusals that have nothing to offer — bytes
 * that are not text, a directory, an unreadable path — which is exactly what
 * {@link candidatesOf} answers for them.
 *
 * `decoded` separates the two refusals that are otherwise identical: admission
 * DID decode the file, and only the binary check then refused it. The caller's
 * placeholder loop needs that, because a file admission decoded has real `text`
 * rows that must be kept, while a file it could not read has none.
 */
export type ReadAttempt = {
    text: string;
    encoding: string;
} | {
    error: unknown;
    decoded?: boolean;
};
/**
 * Read one file's bytes through the plugin's own admission, for the fallback
 * path.
 *
 * The session's recorded encoding is consulted first, so a file the model has
 * already opened with `read({ encoding: "gbk" })` — the documented remedy for a
 * legacy file — is searched under that same encoding rather than reported as
 * undecodable.
 *
 * Never throws: an unreadable file is one unresolved file, not a failed search,
 * so every failure — an aborted read included — comes back as a
 * {@link ReadAttempt} with its reason attached.
 *
 * @param ctx - the plugin context, for `fs`.
 * @param exec - the calling execution, for the abort signal and the records.
 * @param path - the path as ripgrep printed it.
 * @param config - the deployment's admission config.
 * @param cwd - the search's spawn directory, which is what ripgrep printed
 *   `path` relative to.
 * @returns the decoded text and encoding, or the reason there is none.
 */
export declare function readAndDecode(ctx: Context, exec: ToolExecution, path: string, config: PluginConfig, cwd: string): Promise<ReadAttempt>;
