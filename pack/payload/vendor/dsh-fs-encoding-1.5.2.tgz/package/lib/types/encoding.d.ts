/**
 * Encoding primitives — the pure, IO-free half of the VS Code encoding model.
 *
 * Deterministic-first: BOM sniff, then strict UTF-8, then (only when the config
 * opts in) probabilistic scoring over an allowlist. Nothing here touches the
 * filesystem or the harness; callers own admission order and side effects.
 *
 * @module dsh-fs-encoding/encoding
 */
/**
 * Encodings `autoGuessEncoding` may consider when the config does not say otherwise.
 *
 * `windows-1252` belongs here even though the other Windows ANSI pages do not:
 * it is what Windows writes for Western text, and it used to be reachable by
 * accident because `cp1252` was aliased onto `iso-8859-1`. Splitting the two
 * apart without listing it would have taken cp1252 files from "decoded as the
 * right family, lossily" to "guessed as Cyrillic". The remaining pages stay
 * opt-in through `supportedEncodings`, keeping the guess set small and the
 * false-positive rate low.
 */
export declare const DEFAULT_SUPPORTED_ENCODINGS: readonly ["gbk", "big5", "shift_jis", "euc-kr", "windows-1251", "windows-1252", "iso-8859-1"];
/**
 * Every canonical encoding this plugin can read and write.
 *
 * Derived from {@link ALIASES} rather than written out by hand: the two error
 * messages that advertise the supported set used to repeat a literal list, so
 * adding an encoding here and forgetting them made the plugin contradict
 * itself — it would refuse a name that its own help text recommended.
 *
 * Order is the six Unicode names above, then `ALIASES` insertion order (which
 * groups the East Asian pages, then the Windows ANSI family). It is a
 * presentation order for the error message only — nothing depends on it, and
 * no always-sent help text mirrors it.
 */
export declare const CANONICAL_ENCODINGS: readonly string[];
/** The canonical encodings as one comma-separated string for error messages. */
export declare const SUPPORTED_ENCODINGS_TEXT: string;
/**
 * Canonicalize a user/model supplied encoding name.
 *
 * Case-insensitive and punctuation-insensitive: `Shift-JIS`, `shift_jis` and
 * `SJIS` all resolve to `shift_jis`.
 *
 * The lookup is an OWN-property check, not a bare `ALIASES[key]`. A plain
 * object literal inherits `Object.prototype`, so a raw index returns a function
 * for names like `constructor` or `toString` — truthy values that are not
 * strings and not encodings. A bare lookup would let `constructor` pass a
 * `=== undefined` validation, reach the codec layer, and surface the
 * interpreter's own source text in a model-facing error message.
 *
 * @param input - the raw encoding name.
 * @returns the canonical identifier, or `undefined` when unrecognized.
 */
export declare function normalizeEncoding(input: string): string | undefined;
/** Whether {@link normalizeEncoding} recognizes this name. */
export declare function isSupportedEncoding(enc: string): boolean;
/** A BOM signature and the encoding it implies. */
export interface BomInfo {
    /** Canonical encoding the BOM declares. */
    encoding: string;
    /** BOM length in bytes. */
    bomLen: number;
}
/**
 * The BOM bytes an encoding name denotes, or `undefined` for a BOM-free form.
 *
 * @param encoding - a canonical encoding identifier.
 * @returns the BOM prefix to write, or `undefined`.
 */
export declare function bomBytesForEncoding(encoding: string): Uint8Array | undefined;
/**
 * Sniff a leading byte-order mark.
 *
 * @param bytes - the file's leading bytes (the whole file is fine).
 * @returns the BOM, or `undefined` when the content starts with no BOM.
 */
export declare function detectBom(bytes: Uint8Array): BomInfo | undefined;
/**
 * Strict UTF-8 validity — a `fatal` decoder, so malformed sequences are
 * rejected rather than replaced with U+FFFD.
 *
 * @param bytes - candidate bytes.
 * @returns whether the bytes are exactly one valid UTF-8 sequence.
 */
export declare function isValidUtf8(bytes: Uint8Array): boolean;
/** U+FFFD, the replacement character a permissive decode leaves behind. */
export declare const REPLACEMENT_CHAR = "\uFFFD";
/**
 * Whether a script family is registered for this encoding.
 *
 * Exposed so a test can assert that every non-Latin canonical encoding has an
 * entry — a missing one scores lower than its rivals and loses silently, which
 * no round-trip test would catch.
 *
 * @param encoding - canonical encoding identifier.
 */
export declare function hasScriptFamily(encoding: string): boolean;
/** One scored encoding guess with a short human-readable sample. */
export interface CandidatePreview {
    /** Canonical encoding identifier. */
    encoding: string;
    /** Up to 50 characters around the first non-ASCII byte, whitespace-collapsed. */
    sample: string;
    /** Higher is more plausible; `-1000` marks a decode that produced U+FFFD. */
    score: number;
}
/**
 * The byte values a single-byte page leaves unassigned, empty for anything else.
 *
 * A single-byte code page decodes each byte independently and maps exactly 256
 * inputs to 256 outputs, so probing all of them yields 256 characters; a
 * multi-byte or Unicode encoding yields fewer. That is how the pages are told
 * apart here, without a hand-written list.
 *
 * This exists to EXPLAIN a decode failure, never to permit one. `windows-1252`
 * leaves five bytes unassigned (0x81, 0x8D, 0x8F, 0x90, 0x9D), so a real
 * windows-1252 file carrying one produces U+FFFD through no fault of the file —
 * and the generic "the encoding is probably wrong" sends the user to a candidate
 * that mangles the rest of the text. Naming the byte is the useful part.
 *
 * Using the same knowledge to ACCEPT such a decode is what an earlier revision
 * tried, and it corrupted files: a wrong page can hit an unassigned byte too,
 * and the decoded text cannot tell the two cases apart. See
 * {@link isAcceptableDecode}.
 *
 * @param enc - canonical encoding identifier.
 * @returns the unassigned byte values, ascending; empty when none apply.
 */
export declare function unassignedBytes(enc: string): readonly number[];
/**
 * Whether a decode may be used as the file's encoding.
 *
 * U+FFFD is disqualifying, full stop — deliberately stricter than it may look,
 * and the strictness is load-bearing.
 *
 * An earlier revision relaxed this to "accept when the page leaves some byte
 * unassigned", reasoning that such a page cannot avoid producing U+FFFD for its
 * own gaps. That reasoning is sound about the page and wrong about the file: a
 * WRONG page can hit an unassigned byte too. A short Shift-JIS file
 * (`83 52 83 81 83 93 83 67`) contains 0x81, which windows-1252 leaves
 * unassigned — so the relaxed rule accepted windows-1252, `chardet`'s top
 * verdict, and a save then rewrote 0x81 as 0x9D.
 *
 * The round-trip guard did not catch it because the guard compares TEXT, and the
 * text is exactly what stays stable here: 0x81 decodes to U+FFFD, and U+FFFD
 * re-encodes to 0x9D — another byte windows-1252 leaves unassigned — which
 * decodes back to U+FFFD. So the decoded string is a fixed point while the bytes
 * underneath it are not, and a file the user never edited came back changed.
 *
 * The decoded text alone cannot separate "right page, unassigned byte" from
 * "wrong page, unassigned byte", so no counting or per-byte attribution rule can
 * rescue the relaxed form. The unassigned-byte knowledge is still used — to
 * explain the failure (see `firstUnassignedByte`), never to permit it.
 *
 * The rule therefore takes no encoding argument. It once did, and the parameter
 * was what made the relaxed form look principled: a call site reading
 * `isAcceptableDecode(text, enc)` invites the belief that acceptability is a
 * property of the pairing, when it is a property of the text alone. A future
 * rule that genuinely needs the encoding should add the parameter back — the
 * compiler then flags every call site, which is safer than a silently ignored
 * argument.
 *
 * @param text - the decode result.
 * @returns whether the decode may become the file's recorded encoding.
 */
export declare function isAcceptableDecode(text: string): boolean;
/**
 * Score one decoded text under the encoding that produced it.
 *
 * Two terms: how much of the text is printable, and how much of the candidate's
 * own script it contains. The ratio is scaled by 100 and the script bonus by 0.5,
 * so a full page of the right script (bonus in the hundreds) outweighs a couple
 * of percent of printability, while printability still separates a clean decode
 * from one that left C1 control characters behind.
 *
 * The 100 was once 10. That change was measured to be behaviour-neutral — over a
 * 55-sample corpus spanning every supported script plus random binary, both
 * scalings produced identical rankings — so it is kept only as the current
 * calibration, NOT because it fixed a tie: `scoreText` returns a float and the
 * sort compares floats, so 95% and 100% never actually collided. Treat the
 * constants as a pair to re-measure together, not as independently meaningful.
 *
 * The `-500` floor stays far below any surviving decode, so a mostly-binary
 * result still loses outright.
 *
 * @param text - the decode result.
 * @param enc - the encoding that produced it.
 * @returns a comparable score; U+FFFD is disqualifying, with no exception.
 */
export declare function scoreText(text: string, enc: string): number;
/**
 * Decode bytes under one canonical encoding.
 *
 * @param bytes - the raw content, BOM already stripped when the caller handled it.
 * @param enc - canonical encoding identifier.
 * @returns the decoded text, or `undefined` when the bytes do not decode.
 */
export declare function decodeBytes(bytes: Uint8Array, enc: string): string | undefined;
/**
 * The byte-order mark that stops this encoding name from being adopted.
 *
 * A save takes its BOM from the encoding NAME (`encodeForSave`), never from the
 * bytes that were read, so a name and a mark that disagree cannot both survive:
 * a `utf8bom` file read as `utf8` loses its three mark bytes on the next save.
 *
 * The question is asked of the MARK, and only of the mark: does this name write
 * those leading bytes back as CONTENT? A name that reads the mark as ordinary
 * characters — a legacy page reads `EF BB BF` as `ï»¿` — reproduces them and has
 * nothing to refuse, which is why comparing NAMES is wrong. A codec that swallows
 * only PART of a foreign mark is still caught, because `utf16le` reads the `FF FE`
 * of a `utf32le` mark as a character instead of writing it back, so its
 * re-encoding does not begin with those four bytes.
 *
 * Asking it of the WHOLE FILE — whether re-encoding reproduces every byte — is
 * too strong, and the excess is not the conservative kind. `iconv-lite`'s encoders
 * canonicalise rather than invert, so a legal body can hold a non-canonical pair
 * (`A3 A0` for the ideographic space, written back as `A1 A1`) far from the mark.
 * A whole-file compare blames the mark for that, refuses a file whose mark is
 * perfectly reproducible, and names the mark's own encoding as the remedy — a name
 * that cannot decode the body at all. Worse, the refusal lands on the SECOND read
 * of a file the first read accepted, because the session feeds its recorded name
 * back as the hint, so the file stops opening for the rest of the session.
 *
 * Bytes that do not decode under this name are NOT this function's business, and
 * it says so by returning `undefined`. The caller has its own message for that
 * case, and it is the accurate one: reporting a mark problem for `EF BB BF E4 B8`
 * under `utf8` would name `utf8bom` as the remedy for a truncated sequence that
 * `utf8bom` cannot decode either, sending the model in a circle.
 *
 * @param bytes - the file's bytes, BOM included.
 * @param enc - the canonical encoding name being adopted.
 * @returns the mark this name cannot write back, or `undefined` when it can, or
 *   when the question does not arise because the bytes do not decode.
 */
export declare function incompatibleBom(bytes: Uint8Array, enc: string): BomInfo | undefined;
/**
 * Whether a decode may be adopted as the file's encoding.
 *
 * Two questions, asked in this order, and the ORDER is what keeps the answer
 * honest.
 *
 * 1. A decode with no U+FFFD is admissible. Nothing was invented, so there is
 *    nothing to attribute and no further byte-level test to run.
 * 2. A decode WITH U+FFFD is admissible only if the encoding can really SPELL
 *    that character. U+FFFD is an ordinary code point, so `EF BF BD` is a legal
 *    UTF-8 file whose CONTENT holds it — and only bytes that really are the
 *    character re-encode to themselves, which is what {@link roundTrips} asks.
 *
 * A byte-exact round trip ALONE is not the rule, and both halves of that matter.
 * It is too STRICT on the multi-byte pages, because `iconv-lite`'s encoders
 * canonicalise rather than invert: measured, 2091 Shift-JIS byte pairs, 100 Big5
 * and 2 GBK decode to real characters but re-encode to a DIFFERENT pair (`87 90`
 * is `≒`, written back as `81 E0`; `A2 E3` is `€`, written back as `80`). Those
 * are legal, U+FFFD-free files, so a byte test used as the gate refused files the
 * text rule had always accepted — and refused them under the CORRECT encoding
 * too, leaving no way to open them at all.
 *
 * It is too LAX on the single-byte pages, where U+FFFD is not in the page at
 * all: `iconv-lite` encodes it onto one of the page's own unassigned bytes
 * (`0x9D` for windows-1252, `0x98` for windows-1251), and that byte decodes back
 * to U+FFFD — so the round trip succeeds on a U+FFFD the DECODER invented. That
 * is the historical corruption in a new shape: a wrong page adopted as the file's
 * encoding, and a save that rewrites its bytes. {@link unassignedBytes} is what
 * separates the two cases, and it is used here to REFUTE, never to permit — if
 * the character's own encoding lands on a byte the page leaves unassigned, the
 * U+FFFD cannot have come from the file.
 *
 * The text rule ({@link isAcceptableDecode}) still governs the places where the
 * question really is "does this look like text": SCORING ({@link scoreText}) and
 * the chardet verdict filter, which decides which pages are worth SHOWING. It is
 * wrong for ADMISSION only because it cannot tell those two U+FFFDs apart, which
 * is the one thing rule 2 resolves. The two rules therefore coexist deliberately,
 * and the difference is reachable: a legal UTF-32 file whose content holds a
 * literal U+FFFD is dropped by the chardet filter (so guessing cannot pick that
 * page) while an explicit hint for it is admitted here.
 *
 * This asks only about the byte range `text` decodes to. A caller that treats a
 * leading BOM as a PREFIX rather than as content has one more question to ask —
 * whether the name can write that prefix back — and asks it separately with
 * {@link incompatibleBom}, because that check belongs to the caller's BOM
 * handling and not to the text.
 *
 * @param bytes - the byte range `text` decodes to.
 * @param enc - canonical encoding identifier to admit them under.
 * @param text - the decode of `bytes` under `enc`, or `undefined` when they do
 *   not decode at all. Taking the decode as an argument rather than repeating it
 *   keeps the caller's own decode and the admission test from ever disagreeing,
 *   and a failed decode is refused here rather than left to the caller.
 * @returns whether this decode may become the file's encoding.
 */
export declare function isAdoptableDecode(bytes: Uint8Array, enc: string, text: string | undefined): boolean;
/**
 * Encode text under one canonical encoding.
 *
 * Unmappable characters become `?` here; callers that must not silently corrupt
 * content verify the round-trip (see `encodeForSave` in `encoding-state`).
 *
 * @param text - the text to encode.
 * @param enc - canonical encoding identifier.
 * @returns the encoded bytes, or `undefined` when the encoding is unknown.
 */
export declare function encodeText(text: string, enc: string): Uint8Array | undefined;
/**
 * Score every allowlisted encoding and return the best three.
 *
 * @param bytes - the raw content.
 * @param allowlist - candidate encodings, normalized here.
 * @returns up to three candidates, best first.
 */
export declare function top3Candidates(bytes: Uint8Array, allowlist: readonly string[]): CandidatePreview[];
/**
 * One `chardet` verdict that the allowlist and the U+FFFD-free decode both
 * accepted.
 *
 * Structurally a {@link CandidatePreview} plus the verdict's name, which is what
 * lets {@link isFloorVerdict} name the page instead of trusting the
 * confidence number alone — see {@link CHARDET_FLOOR_FAMILIES}.
 *
 * Not exported: it is the return shape of {@link chardetTop3Candidates} for
 * callers inside this module, and nothing outside needs to name it.
 */
interface ChardetVerdict {
    /** Canonical encoding identifier, e.g. `gbk`. */
    encoding: string;
    /** The encoding name `chardet` itself reported, e.g. `GB18030`. */
    chardetName: string;
    /** `chardet`'s confidence in this page. */
    confidence: number;
    /** Up to 50 characters around the first non-ASCII byte, whitespace-collapsed. */
    sample: string;
}
/**
 * Ask the optional `chardet` dependency for candidates, filtered by the
 * allowlist and re-verified by a U+FFFD-free decode.
 *
 * A missing or failing `chardet` is not an error — the caller falls back to
 * {@link top3Candidates}.
 *
 * @param bytes - the raw content.
 * @param allowlist - candidate encodings the deployment permits.
 * @returns candidates with `chardet` confidences, or an empty array.
 */
export declare function chardetTop3Candidates(bytes: Uint8Array, allowlist: readonly string[]): Promise<ChardetVerdict[]>;
/**
 * Candidate list for an error message: `chardet` when it has an opinion,
 * otherwise the heuristic scoring.
 *
 * The two are COMBINED rather than chosen between — see {@link rankCandidates},
 * which owns the ordering rules. This wrapper exists for callers that only need
 * the list and not the evidence flag.
 *
 * @param bytes - the raw content.
 * @param allowlist - candidate encodings the deployment permits.
 * @returns up to {@link CANDIDATE_SLOTS} candidates, best first — or one more
 *   when the list is unranked, see {@link UNRANKED_CANDIDATE_SLOTS}.
 */
export declare function getTop3Candidates(bytes: Uint8Array, allowlist: readonly string[]): Promise<CandidatePreview[]>;
/**
 * The ranked candidates, whether their ORDER carries evidence, and whether the
 * head may be acted on.
 *
 * `ranked` and `basis` travel with the list because the ordering evidence is not
 * recoverable from the list itself: `score` is always one scale (see
 * `unionByScore`), so a caller cannot tell a page that chardet ranked from one
 * the heuristic merely scored.
 *
 * `ranked` and `adoptable` answer DIFFERENT questions and must not be conflated.
 * `ranked` asks "does the order mean anything?" and drives the wording and the
 * guess caveat. `adoptable` asks "may I decode with the head without asking?"
 * and is the only flag a caller may act on. Every combination except
 * `ranked: false, adoptable: true` is reachable — see each field.
 *
 * `basis` is diagnostic: it records which of the three situations produced the
 * list, so a future caller can tell "the heuristic was the only opinion
 * available" (a chardet-less install, still adopted) from "chardet looked and
 * declined".
 */
export interface RankedCandidates {
    /**
     * The candidates. When `ranked` is true they are best-first by the producer
     * that ranked them. When it is false the order is chardet's own verdict order
     * followed by the heuristic's — deterministic, and deliberately NOT the score
     * order, because `scoreText` cannot separate the East Asian pages and sorting
     * by it would put `gbk` first for every one of them (see `rankCandidates`).
     * Such a list must be shown with its samples and read as "pick one", never as
     * a ranking — which is exactly what `ranked: false` tells the caller.
     *
     * A caller must NOT infer from `ranked` that the head is safe to decode with;
     * that is {@link adoptable}. The two come apart in both directions: an
     * abstention the producers agreed on is adoptable but unranked, and a chardet
     * ranking whose head is a single-byte page the bytes contradict is ranked but
     * NOT adoptable.
     */
    candidates: CandidatePreview[];
    /**
     * Whether the order is evidence-backed. False means the head is an arbitrary
     * pick among pages nobody could rank, so it may be shown but must be
     * presented as a guess rather than a decision.
     *
     * True does not imply the head may be used — see {@link adoptable}.
     */
    ranked: boolean;
    /**
     * Whether the caller may DECODE with the head without asking first. This is
     * the flag to act on; `ranked` only governs presentation.
     *
     * Deliberately separate from `ranked`, and the two disagree in both
     * directions:
     *
     * - `ranked: true, adoptable: true` — a genuine chardet ranking, or a
     *   chardet-less install where the heuristic is the only opinion there is.
     * - `ranked: true, adoptable: false` — chardet ranked these pages, but its
     *   head is a single-byte page whose own decode contradicts it
     *   (see `isImplausibleSingleByteHead`). The order is still meaningful, so the
     *   list is shown in order; the head is just not credible enough to use.
     * - `ranked: false, adoptable: true` — an abstention where both producers
     *   happened to name the same page. Agreement is strong evidence (83%
     *   measured) and still not proof, so the caller adopts it while keeping the
     *   "this is a guess" caveat in front of the model.
     * - `ranked: false, adoptable: false` — an abstention where they disagree.
     *   Refusing it is what keeps a page nobody could justify from being recorded
     *   and written back.
     */
    adoptable: boolean;
    /** Which ranking produced `candidates`. Diagnostic, not a control input. */
    basis: "chardet-ranked" | "chardet-abstained" | "heuristic-only";
}
/**
 * Rank the candidates and report whether the ordering means anything.
 *
 * This is where the ranking rules live; {@link getTop3Candidates} is a thin
 * wrapper for callers that need only the list. The split exists so the evidence
 * flag can be computed where the floor test is available, and so it travels with
 * the list it describes — see {@link RankedCandidates}.
 *
 * @param bytes - the raw content.
 * @param allowlist - candidate encodings the deployment permits.
 * @returns the candidates and whether their order is evidence-backed.
 */
export declare function rankCandidates(bytes: Uint8Array, allowlist: readonly string[]): Promise<RankedCandidates>;
export {};
