/**
 * The encoding-governed `undo_last_edit` tool.
 *
 * Reverts a file to the content and the ENCODING it had before its most recent
 * edit, and refuses when the file has changed since — an undo must not discard
 * work it did not make.
 *
 * Both halves of "revert" matter, and the encoding half is the one a content-only
 * undo gets wrong. With `normalizeToUtf8` on, an ordinary save rewrites a legacy
 * file as UTF-8, so restoring the old characters while leaving the file UTF-8
 * would produce a file that never existed: the right text in the wrong encoding.
 * The record therefore carries the pre-edit `FileEncodingState` and the write
 * restores it — see `WriteRequest.restoreState`.
 *
 * The history is IN MEMORY and one edit deep. Two consequences the tool states
 * rather than hides: it does not survive a DSH restart, and editing a file twice
 * leaves only the second edit undoable.
 *
 * @module dsh-fs-encoding/tool-undo
 */
import type { Context } from "@deepseek-ai/cordis";
import type { ToolExecution } from "@deepseek-ai/dsh-tools";
import type { EncodingSandbox, FsEscalationArgs } from "./sandbox.js";
/** What one undo produced, in the shape the tool result carries. */
export interface UndoOutcome {
    /** The path as the caller wrote it. */
    path: string;
    /** The content before the undo (equal to `after` when nothing was reverted). */
    before: string;
    /** The content after the undo (equal to `before` when nothing was reverted). */
    after: string;
    /** Whether the file was actually reverted. */
    undone: boolean;
    /** A sentence explaining the outcome, shown to the model either way. */
    note: string;
}
/** Parse and validate the arguments shared by `undo_last_edit` and `undo_edit`. */
export declare function parseUndoArgs(args: Record<string, unknown>, toolName: string): {
    path: string;
};
/**
 * Revert one file to its pre-edit content and encoding.
 *
 * Shared by the `undo_last_edit` tool and by `str_replace_editor`'s `undo_edit`
 * command, which have identical arguments and must not be able to drift: two
 * implementations of "undo" would eventually disagree about what is undoable.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 * @param path - the path as the caller wrote it.
 * @param exec - the calling execution.
 * @param toolName - the calling tool, for the escalation audit trail.
 * @param escalationArgs - the call's escalation fields, forwarded so an approved
 *   one-shot escalation reaches the fence. Dropping them made the advertised
 *   `sandbox_permissions`/`justification` a no-op, so the sanctioned retry after
 *   a `[sandbox: …]` denial failed identically and forever.
 * @returns what the undo produced.
 */
export declare function performUndo(ctx: Context, sandbox: EncodingSandbox, path: string, exec: ToolExecution, toolName: string, escalationArgs?: FsEscalationArgs): Promise<UndoOutcome>;
/**
 * Render an undo outcome as the message the model reads.
 *
 * @param outcome - what the undo produced.
 * @returns the message.
 */
export declare function formatUndoOutput(outcome: UndoOutcome): string;
/**
 * Build the `undo_last_edit` tool.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 */
export declare function buildUndoTool(ctx: Context, sandbox: EncodingSandbox): import("@deepseek-ai/dsh-tools").ToolDefinition;
