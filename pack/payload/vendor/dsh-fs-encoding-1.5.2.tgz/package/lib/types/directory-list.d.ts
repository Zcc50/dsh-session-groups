/**
 * Directory listing for `str_replace_editor`'s `view` command.
 *
 * The harness's own `view` lists a directory as `type<TAB>path` rows, two levels
 * deep, excluding hidden entries plus `node_modules` and `__pycache__`. That shape
 * is reproduced here rather than approximated, because the model reads it with the
 * habits its training gave it — a different format is a small, silent handicap.
 *
 * Written against `ctx.fs.listDir` rather than forwarded to the harness package:
 * that package exports only `apply` / `Config` / `inject` / `name`, so its
 * `listDirectory` is module-private and cannot be called from outside. Going
 * through `ctx.fs` also keeps the sandbox and target resolution identical to every
 * other tool here.
 *
 * @module dsh-fs-encoding/directory-list
 */
import type { FileSystem, FsTarget } from "@deepseek-ai/dsh-fs";
/** How deep the listing descends below the named directory, matching the harness. */
export declare const LISTING_MAX_DEPTH = 2;
/**
 * How many rows the listing may emit before it is cut off.
 *
 * The harness truncates its listing by character count (`maxOutputChars`); a row
 * cap is the same protection in the unit this function actually builds. Without
 * one, a directory holding tens of thousands of entries (an un-ignored `dist/` or
 * `build/`) produces a result of that many rows, which is then sorted whole and
 * joined into a single string — all of it entering the result value, the session
 * log and, in the worst case, the model's context.
 */
export declare const LISTING_MAX_ROWS = 2000;
/**
 * Render a directory tree as the harness's `view` does.
 *
 * @param fs - the filesystem service.
 * @param target - the resolved directory to list.
 * @param signal - aborts the listing.
 * @returns the listing text, ready to hand to the model.
 */
export declare function listDirectory(fs: FileSystem, target: FsTarget, signal?: AbortSignal): Promise<string>;
