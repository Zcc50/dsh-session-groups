/**
 * System-prompt guidance for the three encoding-governed tools.
 *
 * These sections shadow the built-ins' own `tool:read` / `tool:write` /
 * `tool:edit` sections by name on the agent's layer, so the model is taught the
 * encoding-aware contract instead of the UTF-8-only one. The order values sit
 * above the built-in band (100–116) so a same-order tie with a built-in cannot
 * occur out of the box.
 *
 * @module dsh-fs-encoding/prompts
 */
/** Prompt section names shared with the built-ins — same name, nearer layer wins. */
export declare const SECTION_READ = "tool:read";
export declare const SECTION_WRITE = "tool:write";
export declare const SECTION_EDIT = "tool:edit";
export declare const SECTION_GREP = "tool:grep";
/** Order values, above the built-in tool band to avoid registration-order ties. */
export declare const ORDER_READ = 130;
export declare const ORDER_WRITE = 131;
export declare const ORDER_EDIT = 132;
export declare const ORDER_GREP = 133;
/**
 * The `read` call that re-opens a file under an explicit encoding.
 *
 * The single source for a hint that appears in four places: the `E_NOT_TEXT`
 * message, the auto-guess footer, this module's read section, and the generated
 * config template. They used to be four independent literals, so adding
 * `file_path` to the call meant editing all four — and a site that was missed
 * would hand the model a call the tool's own payload validation rejects, which
 * reads as a second, unrelated error.
 *
 * @param encoding - the encoding to name, or a placeholder when none applies.
 * @param filePath - the path to name, or a placeholder when none applies.
 */
export declare function reReadCall(encoding?: string, filePath?: string): string;
export declare const READ_DESCRIPTION: string;
export declare const WRITE_DESCRIPTION: string;
export declare const EDIT_DESCRIPTION: string;
export declare const INSERT_DESCRIPTION: string;
export declare const STR_REPLACE_EDITOR_DESCRIPTION: string;
export declare const UNDO_DESCRIPTION: string;
export declare const GREP_DESCRIPTION: string;
export declare const GREP_SECTION_TEXT: string;
/**
 * The read result envelope, shared by `read` and by `str_replace_editor`'s `view`.
 *
 * Both tools show the same files to the same model, so they must agree on the
 * output shape AND on the line numbering — a model that read a file with one tool
 * and edits it with the other must not be working from two numbering schemes.
 * The window caps live here too, for the same reason: a file too large for one
 * entry point must not be unbounded through the other.
 */
/** Default line cap, matching the built-in read tool. */
export declare const DEFAULT_LIMIT = 2000;
/** Clip one over-long line the way the built-in read does. */
export declare function clipLine(line: string): string;
/**
 * Render a read window as the harness's `<path>/<type>/<content>` envelope.
 *
 * @param displayPath - the path as the model wrote it.
 * @param lines - the window's lines, each keeping its file line number.
 * @param offset - the 1-based first line of the window.
 * @param totalLines - the file's total line count.
 */
export declare function formatReadOutput(displayPath: string, lines: ReadonlyArray<{
    number: number;
    text: string;
}>, offset: number, totalLines: number): string;
export declare function readSectionText(): string;
export declare function writeSectionText(): string;
export declare function editSectionText(): string;
