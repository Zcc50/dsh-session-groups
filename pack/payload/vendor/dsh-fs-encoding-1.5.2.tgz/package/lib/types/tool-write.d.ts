/**
 * The encoding-governed `write` tool.
 *
 * Contract-compatible with the built-in `write` (same `file_path` / `content`
 * arguments, same `path`/`operation`/`before`/`after` result shape and diff
 * card) but the file is published as bytes in its own recorded encoding instead
 * of always being re-encoded as UTF-8.
 *
 * @module dsh-fs-encoding/tool-write
 */
import type { Context } from "@deepseek-ai/cordis";
import type { EncodingSandbox } from "./sandbox.js";
/**
 * Build the encoding-governed `write` tool.
 *
 * @param ctx - the plugin's host context.
 * @param sandbox - the fence and `fs/*` event gate.
 */
export declare function buildWriteTool(ctx: Context, sandbox: EncodingSandbox): import("@deepseek-ai/dsh-tools").ToolDefinition;
